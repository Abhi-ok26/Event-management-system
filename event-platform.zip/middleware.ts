import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createServerClient } from "@supabase/ssr"

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value
        },
        set(name: string, value: string, options: any) {
          request.cookies.set({
            name,
            value,
            ...options,
          })
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          })
          response.cookies.set({
            name,
            value,
            ...options,
          })
        },
        remove(name: string, options: any) {
          request.cookies.set({
            name,
            value: "",
            ...options,
          })
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          })
          response.cookies.set({
            name,
            value: "",
            ...options,
          })
        },
      },
    },
  )

  // Skip auth check for API routes and diagnostic routes
  if (
    request.nextUrl.pathname.startsWith("/api/") ||
    request.nextUrl.pathname.startsWith("/auth/diagnose") ||
    request.nextUrl.pathname.startsWith("/auth/test") ||
    request.nextUrl.pathname.startsWith("/auth/setup")
  ) {
    return response
  }

  const { data } = await supabase.auth.getSession()

  // Protected routes that require authentication
  const protectedRoutes = ["/dashboard", "/tickets", "/events/*/join"]

  const isProtectedRoute = protectedRoutes.some((route) => {
    if (route.includes("*")) {
      const routePattern = new RegExp(route.replace("*", ".*"))
      return routePattern.test(request.nextUrl.pathname)
    }
    return request.nextUrl.pathname.startsWith(route)
  })

  // Auth routes that should redirect to home if already logged in
  const authRoutes = ["/auth/login", "/auth/register", "/auth/direct-signup"]
  const isAuthRoute = authRoutes.includes(request.nextUrl.pathname)

  // If user is not logged in and trying to access a protected route
  if (isProtectedRoute && !data.session) {
    const redirectUrl = new URL("/auth/login", request.url)
    redirectUrl.searchParams.set("redirect", request.nextUrl.pathname)
    return NextResponse.redirect(redirectUrl)
  }

  // If user is logged in and trying to access auth routes
  if (isAuthRoute && data.session) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  return response
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/tickets/:path*",
    "/events/:path*/join",
    "/auth/login",
    "/auth/register",
    "/auth/direct-signup",
    "/auth/diagnose",
    "/auth/test",
    "/auth/setup",
    "/api/auth/:path*",
  ],
}
