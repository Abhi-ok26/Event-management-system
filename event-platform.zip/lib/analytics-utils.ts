import { formatDate, formatTime } from "./utils"

export type AttendanceData = {
  date: string
  count: number
}

export type EngagementData = {
  userId: string
  userName: string
  joinTime: string
  leaveTime: string | null
  duration: number // in minutes
  isPresenter: boolean
}

export type MeetingAnalytics = {
  totalParticipants: number
  maxConcurrentParticipants: number
  averageDuration: number // in minutes
  attendanceByDay: AttendanceData[]
  participantDetails: EngagementData[]
}

export function calculateMeetingAnalytics(
  participants: any[],
  meetingStartTime: string,
  meetingEndTime: string,
): MeetingAnalytics {
  // Initialize analytics object
  const analytics: MeetingAnalytics = {
    totalParticipants: 0,
    maxConcurrentParticipants: 0,
    averageDuration: 0,
    attendanceByDay: [],
    participantDetails: [],
  }

  if (!participants || participants.length === 0) {
    return analytics
  }

  // Calculate total unique participants
  const uniqueParticipants = new Set(participants.map((p) => p.user_id))
  analytics.totalParticipants = uniqueParticipants.size

  // Process participant details
  const participantMap = new Map<string, EngagementData>()

  participants.forEach((p) => {
    const joinTime = new Date(p.joined_at)
    const leaveTime = p.left_at ? new Date(p.left_at) : null

    // Calculate duration in minutes
    let duration = 0
    if (leaveTime) {
      duration = Math.round((leaveTime.getTime() - joinTime.getTime()) / (1000 * 60))
    } else {
      // If no leave time, assume they're still in the meeting or use meeting end time
      const endTime = new Date(meetingEndTime)
      const now = new Date()
      const referenceTime = now < endTime ? now : endTime
      duration = Math.round((referenceTime.getTime() - joinTime.getTime()) / (1000 * 60))
    }

    const profile = p.profiles || {}

    analytics.participantDetails.push({
      userId: p.user_id,
      userName: profile.full_name || profile.email || "Unknown User",
      joinTime: formatDate(p.joined_at) + " " + formatTime(p.joined_at),
      leaveTime: p.left_at ? formatDate(p.left_at) + " " + formatTime(p.left_at) : null,
      duration,
      isPresenter: p.is_presenter,
    })

    // Track for average calculation
    if (!participantMap.has(p.user_id)) {
      participantMap.set(p.user_id, {
        userId: p.user_id,
        userName: profile.full_name || profile.email || "Unknown User",
        joinTime: formatDate(p.joined_at) + " " + formatTime(p.joined_at),
        leaveTime: p.left_at ? formatDate(p.left_at) + " " + formatTime(p.left_at) : null,
        duration,
        isPresenter: p.is_presenter,
      })
    } else {
      // Update duration if this is a longer session
      const existing = participantMap.get(p.user_id)!
      if (duration > existing.duration) {
        existing.duration = duration
        participantMap.set(p.user_id, existing)
      }
    }
  })

  // Calculate average duration
  const totalDuration = Array.from(participantMap.values()).reduce((sum, p) => sum + p.duration, 0)
  analytics.averageDuration = Math.round(totalDuration / uniqueParticipants.size)

  // Calculate max concurrent participants
  // This is a simplified approach - for a more accurate calculation,
  // we would need to track the exact timeline of joins and leaves
  const timeSlots = new Map<string, number>()

  participants.forEach((p) => {
    const joinDate = new Date(p.joined_at)
    const leaveDate = p.left_at ? new Date(p.left_at) : new Date(meetingEndTime)

    // Track by hour for simplicity
    const currentHour = new Date(joinDate)
    currentHour.setMinutes(0, 0, 0)

    while (currentHour <= leaveDate) {
      const timeKey = currentHour.toISOString()
      timeSlots.set(timeKey, (timeSlots.get(timeKey) || 0) + 1)
      currentHour.setHours(currentHour.getHours() + 1)
    }
  })

  analytics.maxConcurrentParticipants = Math.max(...Array.from(timeSlots.values()), 0)

  // Generate attendance by day
  const attendanceByDay = new Map<string, number>()

  participants.forEach((p) => {
    const date = formatDate(p.joined_at)
    attendanceByDay.set(date, (attendanceByDay.get(date) || 0) + 1)
  })

  analytics.attendanceByDay = Array.from(attendanceByDay.entries()).map(([date, count]) => ({
    date,
    count,
  }))

  return analytics
}
