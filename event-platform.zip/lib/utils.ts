import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date)
}

export function formatTime(dateString: string): string {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "numeric",
    hour12: true,
  }).format(date)
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

export function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diffInSeconds = Math.floor((date.getTime() - now.getTime()) / 1000)

  if (diffInSeconds < 0) {
    return "Event has started"
  }

  const days = Math.floor(diffInSeconds / 86400)
  const hours = Math.floor((diffInSeconds % 86400) / 3600)
  const minutes = Math.floor((diffInSeconds % 3600) / 60)

  if (days > 0) {
    return `${days} day${days > 1 ? "s" : ""}`
  } else if (hours > 0) {
    return `${hours} hour${hours > 1 ? "s" : ""}`
  } else {
    return `${minutes} minute${minutes > 1 ? "s" : ""}`
  }
}

export function generateTicketId(): string {
  return crypto.randomUUID()
}

export async function generateQRCode(data: string): Promise<string> {
  // In a real app, we would use a QR code generation library or API
  // For this mock implementation, we'll return a placeholder image
  // with the data encoded in the URL for demonstration purposes

  // In production, use a proper QR code library like qrcode.react or a service
  const encodedData = encodeURIComponent(data)
  return `/placeholder.svg?height=200&width=200&query=QR Code: ${encodedData}`
}
