export function logAuthDebug(message: string, data?: any) {
  if (process.env.NODE_ENV === "development") {
    console.log(`[AUTH DEBUG] ${message}`, data || "")
  }
}

export function formatError(error: any): string {
  if (typeof error === "string") return error
  if (error?.message) return error.message
  return "An unknown error occurred"
}
