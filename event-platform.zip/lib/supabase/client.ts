import { createBrowserClient } from "@supabase/ssr"
import type { Database } from "@/lib/database.types"

let supabaseBrowserClient: ReturnType<typeof createBrowserClient<Database>> | null = null

export function getSupabaseBrowserClient() {
  if (!supabaseBrowserClient) {
    // Make sure environment variables are available
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseAnonKey) {
      console.error("Supabase environment variables are missing")
      throw new Error("Supabase configuration error")
    }

    supabaseBrowserClient = createBrowserClient<Database>(supabaseUrl, supabaseAnonKey)
  }

  return supabaseBrowserClient
}
