export interface Event {
  id: string
  creator_id: string
  title: string
  description: string | null
  start_time: string
  end_time: string
  category: string | null
  thumbnail_url: string | null
  is_published: boolean
  max_attendees: number | null
  created_at: string
  updated_at: string
  location?: string
}

export interface Profile {
  id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  user_type: string
  created_at: string
  updated_at: string
}

export interface Ticket {
  id: string
  ticket_type_id: string
  event_id: string
  attendee_id: string
  purchase_time: string
  qr_code: string
  is_used: boolean
  scan_time: string | null
  created_at: string
  updated_at: string
}

export interface TicketType {
  id: string
  event_id: string
  name: string
  description: string | null
  price: number
  quantity: number | null
  is_early_bird: boolean
  is_vip: boolean
  sale_starts_at: string | null
  sale_ends_at: string | null
  created_at: string
  updated_at: string
}

export interface MeetingRoom {
  id: string
  event_id: string
  name: string
  description: string | null
  meeting_link: string | null
  password: string | null
  start_time: string
  end_time: string
  is_active: boolean
  max_participants: number | null
  created_at: string
  updated_at: string
}

export interface MeetingParticipant {
  id: string
  meeting_room_id: string
  user_id: string
  joined_at: string
  left_at: string | null
  is_presenter: boolean
  created_at: string
  updated_at: string
}
