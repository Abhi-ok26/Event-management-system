export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          user_type: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          user_type: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          user_type?: string
          created_at?: string
          updated_at?: string
        }
      }
      events: {
        Row: {
          id: string
          creator_id: string
          title: string
          description: string | null
          start_time: string
          end_time: string
          category: string | null
          thumbnail_url: string | null
          is_published: boolean
          max_attendees: number | null
          created_at: string
          updated_at: string
        }
      }
      tickets: {
        Row: {
          id: string
          ticket_type_id: string
          event_id: string
          attendee_id: string
          purchase_time: string
          qr_code: string
          is_used: boolean
          scan_time: string | null
          created_at: string
          updated_at: string
        }
      }
      ticket_types: {
        Row: {
          id: string
          event_id: string
          name: string
          description: string | null
          price: number
          quantity: number | null
          is_early_bird: boolean
          is_vip: boolean
          sale_starts_at: string | null
          sale_ends_at: string | null
          created_at: string
          updated_at: string
        }
      }
    }
  }
}
