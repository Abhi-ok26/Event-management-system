"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Bell, Calendar, LogOut, Menu, User } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import type { Profile } from "@/lib/types"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { toast } from "@/components/ui/use-toast"

export function SiteHeader() {
  const [user, setUser] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const pathname = usePathname()
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    async function getUser() {
      try {
        setIsLoading(true)

        // Check if we're in a browser environment
        if (typeof window === "undefined") {
          console.log("Running on server, skipping auth check")
          setIsLoading(false)
          return
        }

        // Initialize Supabase client
        const supabase = getSupabaseBrowserClient()

        if (!supabase) {
          console.error("Failed to initialize Supabase client")
          setUser(null)
          setIsLoading(false)
          return
        }

        // Get session with error handling
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession()

        if (sessionError) {
          console.error("Error getting session:", sessionError)
          setUser(null)
          setIsLoading(false)
          return
        }

        if (!session) {
          console.log("No active session found")
          setUser(null)
          setIsLoading(false)
          return
        }

        console.log("Session found, fetching user profile...")

        try {
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", session.user.id)
            .single()

          if (profileError) {
            console.error("Error fetching profile:", profileError)

            // If profile doesn't exist, create it
            if (profileError.code === "PGRST116") {
              try {
                const { error: insertError } = await supabase.from("profiles").insert({
                  id: session.user.id,
                  email: session.user.email,
                  full_name: session.user.user_metadata?.full_name || session.user.email?.split("@")[0] || "User",
                  user_type: session.user.user_metadata?.user_type || "attendee",
                  created_at: new Date().toISOString(),
                  updated_at: new Date().toISOString(),
                })

                if (insertError) {
                  console.error("Error creating profile:", insertError)
                  setUser(null)
                } else {
                  // Fetch the newly created profile
                  const { data: newProfile } = await supabase
                    .from("profiles")
                    .select("*")
                    .eq("id", session.user.id)
                    .single()

                  setUser(newProfile as Profile)
                }
              } catch (insertCatchError) {
                console.error("Exception during profile creation:", insertCatchError)
                setUser(null)
              }
            } else {
              setUser(null)
            }
          } else {
            console.log("User profile loaded:", profileData.user_type)
            setUser(profileData as Profile)
          }
        } catch (profileCatchError) {
          console.error("Exception during profile fetch:", profileCatchError)
          setUser(null)
        }
      } catch (error) {
        console.error("Unexpected error in getUser:", error)
        setUser(null)
      } finally {
        setIsLoading(false)
      }
    }

    getUser()
  }, [pathname]) // Re-fetch when pathname changes to ensure UI updates after login/logout

  const handleSignOut = async () => {
    try {
      const supabase = getSupabaseBrowserClient()
      if (!supabase) {
        console.error("Failed to initialize Supabase client")
        toast({
          title: "Error signing out",
          description: "Could not connect to authentication service",
          variant: "destructive",
        })
        return
      }

      await supabase.auth.signOut()
      setUser(null)
      toast({
        title: "Signed out successfully",
      })
      router.push("/")
      router.refresh()
    } catch (error) {
      console.error("Error signing out:", error)
      toast({
        title: "Error signing out",
        description: "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Discover Events", href: "/events" },
    ...(user?.user_type === "creator" ? [{ name: "Creator Dashboard", href: "/dashboard/creator" }] : []),
    ...(user?.user_type === "attendee" ? [{ name: "My Tickets", href: "/dashboard/attendee" }] : []),
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <Calendar className="h-6 w-6" />
            <span className="font-bold inline-block">EventHub</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  pathname === item.href ? "text-foreground" : "text-foreground/60"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-2">
          {!isLoading && !user ? (
            <div className="flex items-center gap-2">
              <Link href="/auth/login">
                <Button variant="ghost" size="sm">
                  Login
                </Button>
              </Link>
              <Link href="/auth/register">
                <Button size="sm">Sign Up</Button>
              </Link>
            </div>
          ) : !isLoading && user ? (
            <>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 flex h-2 w-2 rounded-full bg-primary"></span>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.full_name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={user.user_type === "creator" ? "/dashboard/creator" : "/dashboard/attendee"}>
                      Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : null}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col gap-4 mt-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`text-sm font-medium transition-colors hover:text-primary ${
                      pathname === item.href ? "text-foreground" : "text-foreground/60"
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
                {!user && (
                  <>
                    <Link href="/auth/login" className="text-sm font-medium">
                      Login
                    </Link>
                    <Link href="/auth/register" className="text-sm font-medium">
                      Sign Up
                    </Link>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
