import Image from "next/image"
import Link from "next/link"
import { CalendarDays, Clock, ExternalLink } from "lucide-react"
import type { Event, Ticket, TicketType } from "@/lib/types"
import { formatDate, formatTime } from "@/lib/utils"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface TicketCardProps {
  ticket: Ticket
  event: Event
  ticketType: TicketType
}

export function TicketCard({ ticket, event, ticketType }: TicketCardProps) {
  const isUpcoming = new Date(event.start_time) > new Date()
  const isLive = new Date(event.start_time) <= new Date() && new Date(event.end_time) >= new Date()
  const isPast = new Date(event.end_time) < new Date()

  return (
    <Card>
      <div className="flex flex-col md:flex-row">
        <div className="relative h-48 w-full md:w-1/3">
          <Image
            src={event.thumbnail_url || "/placeholder.svg?height=192&width=192&query=event"}
            alt={event.title}
            fill
            className="object-cover"
          />
          <Badge className="absolute top-2 right-2" variant={isPast ? "outline" : isLive ? "destructive" : "default"}>
            {isPast ? "Past" : isLive ? "Live Now" : "Upcoming"}
          </Badge>
        </div>
        <div className="flex flex-1 flex-col">
          <CardHeader>
            <CardTitle className="line-clamp-1">{event.title}</CardTitle>
            <CardDescription>Ticket: {ticketType.name}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center text-sm">
              <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>{formatDate(event.start_time)}</span>
            </div>
            <div className="flex items-center text-sm">
              <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>
                {formatTime(event.start_time)} - {formatTime(event.end_time)}
              </span>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Link href={`/tickets/${ticket.id}`}>
              <Button variant="outline" size="sm">
                View Ticket
              </Button>
            </Link>
            {isLive && (
              <Link href={`/events/${event.id}/join`}>
                <Button size="sm">
                  Join Event
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            )}
          </CardFooter>
        </div>
      </div>
    </Card>
  )
}
