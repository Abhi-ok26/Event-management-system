"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { generateQRCode } from "@/lib/utils"

interface QRCodeDisplayProps {
  data: string
  size?: number
}

export function QRCodeDisplay({ data, size = 200 }: QRCodeDisplayProps) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function generateCode() {
      try {
        setIsLoading(true)
        const url = await generateQRCode(data)
        setQrCodeUrl(url)
      } catch (err) {
        console.error("Error generating QR code:", err)
        setError("Failed to generate QR code")
      } finally {
        setIsLoading(false)
      }
    }

    generateCode()
  }, [data])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center" style={{ width: size, height: size }}>
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center" style={{ width: size, height: size }}>
        <p className="text-destructive text-sm">{error}</p>
      </div>
    )
  }

  return qrCodeUrl ? (
    <div className="relative" style={{ width: size, height: size }}>
      <Image
        src={qrCodeUrl || "/placeholder.svg"}
        alt="Ticket QR Code"
        width={size}
        height={size}
        className="rounded-md"
      />
    </div>
  ) : null
}
