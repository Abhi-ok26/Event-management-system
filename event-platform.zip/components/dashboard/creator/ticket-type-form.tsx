"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import type { TicketType } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

const ticketTypeFormSchema = z.object({
  name: z.string().min(3, {
    message: "Name must be at least 3 characters.",
  }),
  description: z.string().optional(),
  price: z.string().min(1, {
    message: "Price is required.",
  }),
  quantity: z.string().optional(),
  isEarlyBird: z.boolean().default(false),
  isVip: z.boolean().default(false),
  saleStartsAt: z.string().optional(),
  saleEndsAt: z.string().optional(),
})

type TicketTypeFormValues = z.infer<typeof ticketTypeFormSchema>

interface TicketTypeFormProps {
  eventId: string
  ticketType?: TicketType
}

export function TicketTypeForm({ eventId, ticketType }: TicketTypeFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const form = useForm<TicketTypeFormValues>({
    resolver: zodResolver(ticketTypeFormSchema),
    defaultValues: ticketType
      ? {
          name: ticketType.name,
          description: ticketType.description || "",
          price: ticketType.price.toString(),
          quantity: ticketType.quantity?.toString() || "",
          isEarlyBird: ticketType.is_early_bird,
          isVip: ticketType.is_vip,
          saleStartsAt: ticketType.sale_starts_at ? new Date(ticketType.sale_starts_at).toISOString().slice(0, 16) : "",
          saleEndsAt: ticketType.sale_ends_at ? new Date(ticketType.sale_ends_at).toISOString().slice(0, 16) : "",
        }
      : {
          name: "",
          description: "",
          price: "",
          quantity: "",
          isEarlyBird: false,
          isVip: false,
          saleStartsAt: "",
          saleEndsAt: "",
        },
  })

  async function onSubmit(data: TicketTypeFormValues) {
    setIsLoading(true)
    try {
      const ticketTypeData = {
        event_id: eventId,
        name: data.name,
        description: data.description || null,
        price: Number.parseFloat(data.price),
        quantity: data.quantity ? Number.parseInt(data.quantity) : null,
        is_early_bird: data.isEarlyBird,
        is_vip: data.isVip,
        sale_starts_at: data.saleStartsAt ? new Date(data.saleStartsAt).toISOString() : null,
        sale_ends_at: data.saleEndsAt ? new Date(data.saleEndsAt).toISOString() : null,
      }

      if (ticketType) {
        // Update existing ticket type
        const { error } = await supabase.from("ticket_types").update(ticketTypeData).eq("id", ticketType.id)

        if (error) throw error

        toast({
          title: "Ticket type updated",
          description: "Your ticket type has been updated successfully.",
        })
      } else {
        // Create new ticket type
        const { error } = await supabase.from("ticket_types").insert(ticketTypeData)

        if (error) throw error

        toast({
          title: "Ticket type created",
          description: "Your ticket type has been created successfully.",
        })
      }

      router.refresh()
      router.push(`/dashboard/creator/events/${eventId}`)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ticket Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter ticket name" {...field} />
              </FormControl>
              <FormDescription>For example: General Admission, VIP, Early Bird</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Enter ticket description" className="min-h-20" {...field} />
              </FormControl>
              <FormDescription>Describe what this ticket includes.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Price</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} />
                </FormControl>
                <FormDescription>Set to 0 for free tickets.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="quantity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quantity</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Enter quantity" {...field} />
                </FormControl>
                <FormDescription>Leave empty for unlimited tickets.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="saleStartsAt"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Sale Starts At</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormDescription>When ticket sales begin.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="saleEndsAt"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Sale Ends At</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormDescription>When ticket sales end.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="isEarlyBird"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Early Bird</FormLabel>
                  <FormDescription>Mark this ticket as an early bird special.</FormDescription>
                </div>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isVip"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>VIP</FormLabel>
                  <FormDescription>Mark this ticket as a VIP ticket.</FormDescription>
                </div>
              </FormItem>
            )}
          />
        </div>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Saving..." : ticketType ? "Update Ticket Type" : "Create Ticket Type"}
        </Button>
      </form>
    </Form>
  )
}
