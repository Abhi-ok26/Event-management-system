"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CalendarIcon, Clock } from "lucide-react"
import { format } from "date-fns"
import { createMeetingRoom, updateMeetingRoom } from "@/app/actions/meeting-room-actions"
import type { MeetingRoom } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

interface MeetingRoomFormProps {
  eventId: string
  meetingRoom?: MeetingRoom
  eventStartTime?: string
  eventEndTime?: string
}

export function MeetingRoomForm({ eventId, meetingRoom, eventStartTime, eventEndTime }: MeetingRoomFormProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [startDate, setStartDate] = useState<Date | undefined>(
    meetingRoom ? new Date(meetingRoom.start_time) : eventStartTime ? new Date(eventStartTime) : undefined,
  )
  const [endDate, setEndDate] = useState<Date | undefined>(
    meetingRoom ? new Date(meetingRoom.end_time) : eventEndTime ? new Date(eventEndTime) : undefined,
  )

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const formData = new FormData(e.currentTarget)

      // Add the dates to the form data
      if (startDate) {
        formData.set("startTime", startDate.toISOString())
      }
      if (endDate) {
        formData.set("endTime", endDate.toISOString())
      }

      const result = meetingRoom ? await updateMeetingRoom(formData) : await createMeetingRoom(formData)

      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Success",
          description: meetingRoom ? "Meeting room updated successfully" : "Meeting room created successfully",
        })
        router.push(`/dashboard/creator/events/${eventId}`)
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <input type="hidden" name="eventId" value={eventId} />
      {meetingRoom && <input type="hidden" name="meetingRoomId" value={meetingRoom.id} />}

      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Meeting Room Name</Label>
          <Input
            id="name"
            name="name"
            defaultValue={meetingRoom?.name || ""}
            placeholder="e.g., Main Conference Room"
            required
          />
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            name="description"
            defaultValue={meetingRoom?.description || ""}
            placeholder="Describe what this meeting room is for..."
            rows={3}
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <Label>Start Time</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {startDate ? format(startDate, "PPP p") : <span>Select date and time</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={startDate}
                  onSelect={(date) => {
                    if (date) {
                      const newDate = new Date(date)
                      if (startDate) {
                        newDate.setHours(startDate.getHours())
                        newDate.setMinutes(startDate.getMinutes())
                      }
                      setStartDate(newDate)
                    }
                  }}
                  initialFocus
                />
                <div className="border-t p-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="startHour">Time:</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        id="startHour"
                        className="w-16"
                        type="number"
                        min={0}
                        max={23}
                        value={startDate ? startDate.getHours() : 9}
                        onChange={(e) => {
                          if (startDate) {
                            const newDate = new Date(startDate)
                            newDate.setHours(Number.parseInt(e.target.value) || 0)
                            setStartDate(newDate)
                          }
                        }}
                      />
                      <span>:</span>
                      <Input
                        id="startMinute"
                        className="w-16"
                        type="number"
                        min={0}
                        max={59}
                        step={5}
                        value={startDate ? startDate.getMinutes() : 0}
                        onChange={(e) => {
                          if (startDate) {
                            const newDate = new Date(startDate)
                            newDate.setMinutes(Number.parseInt(e.target.value) || 0)
                            setStartDate(newDate)
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          <div>
            <Label>End Time</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <Clock className="mr-2 h-4 w-4" />
                  {endDate ? format(endDate, "PPP p") : <span>Select date and time</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={endDate}
                  onSelect={(date) => {
                    if (date) {
                      const newDate = new Date(date)
                      if (endDate) {
                        newDate.setHours(endDate.getHours())
                        newDate.setMinutes(endDate.getMinutes())
                      }
                      setEndDate(newDate)
                    }
                  }}
                  initialFocus
                />
                <div className="border-t p-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="endHour">Time:</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        id="endHour"
                        className="w-16"
                        type="number"
                        min={0}
                        max={23}
                        value={endDate ? endDate.getHours() : 17}
                        onChange={(e) => {
                          if (endDate) {
                            const newDate = new Date(endDate)
                            newDate.setHours(Number.parseInt(e.target.value) || 0)
                            setEndDate(newDate)
                          }
                        }}
                      />
                      <span>:</span>
                      <Input
                        id="endMinute"
                        className="w-16"
                        type="number"
                        min={0}
                        max={59}
                        step={5}
                        value={endDate ? endDate.getMinutes() : 0}
                        onChange={(e) => {
                          if (endDate) {
                            const newDate = new Date(endDate)
                            newDate.setMinutes(Number.parseInt(e.target.value) || 0)
                            setEndDate(newDate)
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div>
          <Label htmlFor="meetingLink">Meeting Link</Label>
          <Input
            id="meetingLink"
            name="meetingLink"
            type="url"
            defaultValue={meetingRoom?.meeting_link || ""}
            placeholder="e.g., https://zoom.us/j/123456789"
          />
          <p className="mt-1 text-sm text-muted-foreground">
            Enter a Zoom, Google Meet, or other video conferencing link
          </p>
        </div>

        <div>
          <Label htmlFor="password">Meeting Password (Optional)</Label>
          <Input
            id="password"
            name="password"
            defaultValue={meetingRoom?.password || ""}
            placeholder="Enter password if required"
          />
        </div>

        <div>
          <Label htmlFor="maxParticipants">Maximum Participants (Optional)</Label>
          <Input
            id="maxParticipants"
            name="maxParticipants"
            type="number"
            min={1}
            defaultValue={meetingRoom?.max_participants || ""}
            placeholder="Leave blank for unlimited"
          />
        </div>

        {meetingRoom && (
          <div className="flex items-center space-x-2">
            <Switch id="isActive" name="isActive" defaultChecked={meetingRoom.is_active} />
            <Label htmlFor="isActive">Meeting room is active</Label>
          </div>
        )}
      </div>

      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.push(`/dashboard/creator/events/${eventId}`)}
          disabled={isSubmitting}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Saving..." : meetingRoom ? "Update Meeting Room" : "Create Meeting Room"}
        </Button>
      </div>
    </form>
  )
}
