"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"

import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

interface PublishEventFormProps {
  eventId: string
}

export function PublishEventForm({ eventId }: PublishEventFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  async function onPublish() {
    setIsLoading(true)
    try {
      const { error } = await supabase.from("events").update({ is_published: true }).eq("id", eventId)

      if (error) throw error

      toast({
        title: "Event published",
        description: "Your event has been published successfully.",
      })

      router.push(`/dashboard/creator/events/${eventId}`)
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={onPublish} disabled={isLoading}>
      {isLoading ? "Publishing..." : "Publish Event"}
    </Button>
  )
}
