"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import type { Event } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

const eventFormSchema = z.object({
  title: z.string().min(3, {
    message: "Title must be at least 3 characters.",
  }),
  description: z.string().min(10, {
    message: "Description must be at least 10 characters.",
  }),
  category: z.string().min(1, {
    message: "Please select a category.",
  }),
  startTime: z.string().min(1, {
    message: "Please select a start time.",
  }),
  endTime: z.string().min(1, {
    message: "Please select an end time.",
  }),
  maxAttendees: z.string().optional(),
  thumbnailUrl: z.string().url().optional().or(z.literal("")),
})

type EventFormValues = z.infer<typeof eventFormSchema>

const categories = ["Technology", "Business", "Design", "Marketing", "Health", "Education", "Entertainment", "Other"]

interface EventFormProps {
  event?: Event
}

export function EventForm({ event }: EventFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: event
      ? {
          title: event.title,
          description: event.description || "",
          category: event.category || "",
          startTime: new Date(event.start_time).toISOString().slice(0, 16),
          endTime: new Date(event.end_time).toISOString().slice(0, 16),
          maxAttendees: event.max_attendees?.toString() || "",
          thumbnailUrl: event.thumbnail_url || "",
        }
      : {
          title: "",
          description: "",
          category: "",
          startTime: "",
          endTime: "",
          maxAttendees: "",
          thumbnailUrl: "",
        },
  })

  async function onSubmit(data: EventFormValues) {
    setIsLoading(true)
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("You must be logged in to create an event")
      }

      const eventData = {
        title: data.title,
        description: data.description,
        category: data.category,
        start_time: new Date(data.startTime).toISOString(),
        end_time: new Date(data.endTime).toISOString(),
        max_attendees: data.maxAttendees ? Number.parseInt(data.maxAttendees) : null,
        thumbnail_url: data.thumbnailUrl || null,
        is_published: false,
        creator_id: user.id,
      }

      if (event) {
        // Update existing event
        const { error } = await supabase.from("events").update(eventData).eq("id", event.id)

        if (error) throw error

        toast({
          title: "Event updated",
          description: "Your event has been updated successfully.",
        })
      } else {
        // Create new event
        const { error, data: newEvent } = await supabase.from("events").insert(eventData).select().single()

        if (error) throw error

        toast({
          title: "Event created",
          description: "Your event has been created successfully.",
        })

        // Redirect to the event page
        router.push(`/dashboard/creator/events/${newEvent.id}`)
      }

      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Event Title</FormLabel>
              <FormControl>
                <Input placeholder="Enter event title" {...field} />
              </FormControl>
              <FormDescription>This is the name of your event that attendees will see.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Enter event description" className="min-h-32" {...field} />
              </FormControl>
              <FormDescription>
                Provide details about your event to help attendees understand what to expect.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Category</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>Select a category that best describes your event.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="maxAttendees"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Maximum Attendees</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Enter maximum number of attendees" {...field} />
                </FormControl>
                <FormDescription>Leave empty for unlimited attendees.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="startTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Time</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="endTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>End Time</FormLabel>
                <FormControl>
                  <Input type="datetime-local" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <FormField
          control={form.control}
          name="thumbnailUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Thumbnail URL</FormLabel>
              <FormControl>
                <Input placeholder="Enter thumbnail URL" {...field} />
              </FormControl>
              <FormDescription>Provide a URL for the event thumbnail image.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Saving..." : event ? "Update Event" : "Create Event"}
        </Button>
      </form>
    </Form>
  )
}
