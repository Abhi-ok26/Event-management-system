"use client"

import { useState } from "react"
import { Search, User } from "lucide-react"
import type { EngagementData } from "@/lib/analytics-utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface ParticipantDetailsTableProps {
  participants: EngagementData[]
}

export function ParticipantDetailsTable({ participants }: ParticipantDetailsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState<"name" | "duration" | "joinTime">("joinTime")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  const handleSort = (column: "name" | "duration" | "joinTime") => {
    if (sortBy === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortDirection("asc")
    }
  }

  const filteredParticipants = participants.filter((p) => p.userName.toLowerCase().includes(searchTerm.toLowerCase()))

  const sortedParticipants = [...filteredParticipants].sort((a, b) => {
    if (sortBy === "name") {
      return sortDirection === "asc" ? a.userName.localeCompare(b.userName) : b.userName.localeCompare(a.userName)
    } else if (sortBy === "duration") {
      return sortDirection === "asc" ? a.duration - b.duration : b.duration - a.duration
    } else {
      // joinTime
      return sortDirection === "asc" ? a.joinTime.localeCompare(b.joinTime) : b.joinTime.localeCompare(a.joinTime)
    }
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <User className="mr-2 h-5 w-5" />
          Participant Details
        </CardTitle>
        <CardDescription>Detailed information about each participant</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search participants..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <Button variant="ghost" className="p-0 font-medium" onClick={() => handleSort("name")}>
                    Participant
                    {sortBy === "name" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
                  </Button>
                </TableHead>
                <TableHead>
                  <Button variant="ghost" className="p-0 font-medium" onClick={() => handleSort("joinTime")}>
                    Join Time
                    {sortBy === "joinTime" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
                  </Button>
                </TableHead>
                <TableHead>Leave Time</TableHead>
                <TableHead>
                  <Button variant="ghost" className="p-0 font-medium" onClick={() => handleSort("duration")}>
                    Duration
                    {sortBy === "duration" && <span className="ml-1">{sortDirection === "asc" ? "↑" : "↓"}</span>}
                  </Button>
                </TableHead>
                <TableHead>Role</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedParticipants.map((participant, index) => (
                <TableRow key={`${participant.userId}-${index}`}>
                  <TableCell className="font-medium">{participant.userName}</TableCell>
                  <TableCell>{participant.joinTime}</TableCell>
                  <TableCell>{participant.leaveTime || "Still in meeting"}</TableCell>
                  <TableCell>{participant.duration} min</TableCell>
                  <TableCell>
                    {participant.isPresenter ? (
                      <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                        Host
                      </span>
                    ) : (
                      <span className="rounded-full bg-muted px-2 py-1 text-xs font-medium">Attendee</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}

              {sortedParticipants.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center">
                    No participants found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
