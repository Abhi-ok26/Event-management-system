"use client"
import Link from "next/link"
import { format } from "date-fns"
import { BarChart, Calendar, Clock, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface MeetingAnalyticsCardProps {
  id: string
  eventId: string
  name: string
  startTime: string
  endTime: string
  participantCount: number
}

export function MeetingAnalyticsCard({
  id,
  eventId,
  name,
  startTime,
  endTime,
  participantCount,
}: MeetingAnalyticsCardProps) {
  const formattedStartTime = new Date(startTime)
  const formattedEndTime = new Date(endTime)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart className="mr-2 h-5 w-5 text-primary" />
          {name}
        </CardTitle>
        <CardDescription>Meeting Room Analytics</CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center text-sm">
          <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>{format(formattedStartTime, "PPP")}</span>
        </div>
        <div className="flex items-center text-sm">
          <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>
            {format(formattedStartTime, "p")} - {format(formattedEndTime, "p")}
          </span>
        </div>
        <div className="flex items-center text-sm">
          <Users className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>{participantCount} participants</span>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/dashboard/creator/events/${eventId}/analytics/meetings/${id}`} className="w-full">
          <Button variant="outline" className="w-full">
            View Detailed Analytics
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
