"use client"

import { useEffect, useRef } from "react"
import { BarChart3, Clock } from "lucide-react"
import type { MeetingAnalytics } from "@/lib/analytics-utils"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface AnalyticsChartsProps {
  analytics: MeetingAnalytics
}

export function AnalyticsCharts({ analytics }: AnalyticsChartsProps) {
  const attendanceChartRef = useRef<HTMLCanvasElement>(null)
  const durationChartRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    // This is a simplified implementation
    // In a real application, you would use a charting library like Chart.js
    if (attendanceChartRef.current) {
      const ctx = attendanceChartRef.current.getContext("2d")
      if (ctx) {
        // Clear previous chart
        ctx.clearRect(0, 0, attendanceChartRef.current.width, attendanceChartRef.current.height)

        // Draw attendance chart
        const data = analytics.attendanceByDay
        const maxCount = Math.max(...data.map((d) => d.count), 1)
        const barWidth = attendanceChartRef.current.width / (data.length || 1) - 10

        // Draw bars
        data.forEach((item, index) => {
          const barHeight = (item.count / maxCount) * (attendanceChartRef.current!.height - 40)
          const x = index * (barWidth + 10) + 5
          const y = attendanceChartRef.current!.height - barHeight - 20

          ctx.fillStyle = "#0ea5e9"
          ctx.fillRect(x, y, barWidth, barHeight)

          // Draw date label
          ctx.fillStyle = "#64748b"
          ctx.font = "10px sans-serif"
          ctx.fillText(item.date, x, attendanceChartRef.current!.height - 5)

          // Draw count
          ctx.fillStyle = "#0f172a"
          ctx.font = "12px sans-serif"
          ctx.fillText(item.count.toString(), x + barWidth / 2 - 5, y - 5)
        })
      }
    }

    // Draw duration distribution chart
    if (durationChartRef.current) {
      const ctx = durationChartRef.current.getContext("2d")
      if (ctx) {
        // Clear previous chart
        ctx.clearRect(0, 0, durationChartRef.current.width, durationChartRef.current.height)

        // Group durations into buckets
        const durations = analytics.participantDetails.map((p) => p.duration)
        const buckets = [
          { label: "0-5 min", count: 0 },
          { label: "5-15 min", count: 0 },
          { label: "15-30 min", count: 0 },
          { label: "30-60 min", count: 0 },
          { label: "60+ min", count: 0 },
        ]

        durations.forEach((duration) => {
          if (duration < 5) buckets[0].count++
          else if (duration < 15) buckets[1].count++
          else if (duration < 30) buckets[2].count++
          else if (duration < 60) buckets[3].count++
          else buckets[4].count++
        })

        const maxCount = Math.max(...buckets.map((b) => b.count), 1)
        const barWidth = durationChartRef.current.width / buckets.length - 10

        // Draw bars
        buckets.forEach((bucket, index) => {
          const barHeight = (bucket.count / maxCount) * (durationChartRef.current!.height - 40)
          const x = index * (barWidth + 10) + 5
          const y = durationChartRef.current!.height - barHeight - 20

          ctx.fillStyle = "#10b981"
          ctx.fillRect(x, y, barWidth, barHeight)

          // Draw label
          ctx.fillStyle = "#64748b"
          ctx.font = "10px sans-serif"
          ctx.fillText(bucket.label, x, durationChartRef.current!.height - 5)

          // Draw count
          ctx.fillStyle = "#0f172a"
          ctx.font = "12px sans-serif"
          ctx.fillText(bucket.count.toString(), x + barWidth / 2 - 5, y - 5)
        })
      }
    }
  }, [analytics])

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" />
            Attendance by Day
          </CardTitle>
          <CardDescription>Number of participants per day</CardDescription>
        </CardHeader>
        <CardContent>
          <canvas ref={attendanceChartRef} width={400} height={200} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="mr-2 h-5 w-5" />
            Duration Distribution
          </CardTitle>
          <CardDescription>How long participants stayed in the meeting</CardDescription>
        </CardHeader>
        <CardContent>
          <canvas ref={durationChartRef} width={400} height={200} />
        </CardContent>
      </Card>
    </div>
  )
}
