"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import type { MeetingRoom } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { MeetingRoomCard } from "@/components/events/meeting-room-card"

interface MeetingRoomSectionProps {
  eventId: string
  hasTicket: boolean
  isCreator: boolean
}

export function MeetingRoomSection({ eventId, hasTicket, isCreator }: MeetingRoomSectionProps) {
  const supabase = getSupabaseBrowserClient()
  const [isLoading, setIsLoading] = useState(true)
  const [meetingRooms, setMeetingRooms] = useState<MeetingRoom[]>([])

  useEffect(() => {
    async function loadMeetingRooms() {
      try {
        setIsLoading(true)

        const { data, error } = await supabase
          .from("meeting_rooms")
          .select("*")
          .eq("event_id", eventId)
          .order("start_time", { ascending: true })

        if (error) {
          console.error("Error loading meeting rooms:", error)
        } else {
          setMeetingRooms(data as MeetingRoom[])
        }
      } catch (error) {
        console.error("Error loading meeting rooms:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadMeetingRooms()
  }, [eventId, supabase])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Virtual Meeting Rooms</CardTitle>
          <CardDescription>Loading meeting rooms...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse h-24 bg-muted rounded-md"></div>
        </CardContent>
      </Card>
    )
  }

  if (meetingRooms.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Virtual Meeting Rooms</CardTitle>
          <CardDescription>
            {isCreator
              ? "Create virtual meeting rooms for your event attendees"
              : "This event has no virtual meeting rooms yet"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {isCreator
              ? "Virtual meeting rooms allow your attendees to join live sessions during the event."
              : "Check back later for virtual meeting rooms."}
          </p>
        </CardContent>
        {isCreator && (
          <CardFooter>
            <Link href={`/dashboard/creator/events/${eventId}/meeting-room`} className="w-full">
              <Button className="w-full">Create Meeting Room</Button>
            </Link>
          </CardFooter>
        )}
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Virtual Meeting Rooms</CardTitle>
        <CardDescription>
          {hasTicket || isCreator
            ? "Join virtual meeting rooms during the event"
            : "Purchase a ticket to access virtual meeting rooms"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {meetingRooms.map((meetingRoom) => (
          <MeetingRoomCard
            key={meetingRoom.id}
            meetingRoom={meetingRoom}
            eventId={eventId}
            hasTicket={hasTicket}
            isCreator={isCreator}
          />
        ))}
      </CardContent>
      {isCreator && (
        <CardFooter>
          <Link href={`/dashboard/creator/events/${eventId}/meeting-room`} className="w-full">
            <Button variant="outline" className="w-full">
              {meetingRooms.length > 0 ? "Manage Meeting Rooms" : "Create Meeting Room"}
            </Button>
          </Link>
        </CardFooter>
      )}
    </Card>
  )
}
