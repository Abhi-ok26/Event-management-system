"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { format, isPast, isFuture } from "date-fns"
import { CalendarClock, Users, Video } from "lucide-react"
import { joinMeetingRoom } from "@/app/actions/meeting-room-actions"
import type { MeetingRoom } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

interface MeetingRoomCardProps {
  meetingRoom: MeetingRoom
  eventId: string
  hasTicket: boolean
  isCreator: boolean
}

export function MeetingRoomCard({ meetingRoom, eventId, hasTicket, isCreator }: MeetingRoomCardProps) {
  const router = useRouter()
  const [isJoining, setIsJoining] = useState(false)

  const startTime = new Date(meetingRoom.start_time)
  const endTime = new Date(meetingRoom.end_time)
  const now = new Date()

  const isLive = now >= startTime && now <= endTime && meetingRoom.is_active
  const isPending = isFuture(startTime)
  const isEnded = isPast(endTime)

  const handleJoinMeeting = async () => {
    if (!hasTicket && !isCreator) {
      toast({
        title: "Access Denied",
        description: "You need a ticket to join this meeting",
        variant: "destructive",
      })
      return
    }

    if (!isLive) {
      if (isPending) {
        toast({
          title: "Meeting Not Started",
          description: `This meeting will start on ${format(startTime, "PPP")} at ${format(startTime, "p")}`,
        })
      } else if (isEnded) {
        toast({
          title: "Meeting Ended",
          description: "This meeting has already ended",
        })
      } else {
        toast({
          title: "Meeting Inactive",
          description: "This meeting is currently inactive",
        })
      }
      return
    }

    setIsJoining(true)

    try {
      const result = await joinMeetingRoom(meetingRoom.id, eventId)

      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      } else {
        // Redirect to the meeting room or external link
        if (meetingRoom.meeting_link) {
          window.open(meetingRoom.meeting_link, "_blank")
        } else {
          router.push(`/events/${eventId}/meeting/${meetingRoom.id}`)
        }
      }
    } catch (error) {
      console.error("Error joining meeting:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsJoining(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Video className="mr-2 h-5 w-5 text-primary" />
          {meetingRoom.name}
          {isLive && (
            <span className="ml-2 rounded-full bg-red-100 px-2 py-1 text-xs font-medium text-red-800">LIVE</span>
          )}
        </CardTitle>
        <CardDescription>{meetingRoom.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center text-sm">
          <CalendarClock className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>
            {format(startTime, "PPP")} • {format(startTime, "p")} - {format(endTime, "p")}
          </span>
        </div>
        {meetingRoom.max_participants && (
          <div className="flex items-center text-sm">
            <Users className="mr-2 h-4 w-4 text-muted-foreground" />
            <span>Max {meetingRoom.max_participants} participants</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {isCreator && (
          <Link href={`/dashboard/creator/events/${eventId}/meeting-room`}>
            <Button variant="outline" size="sm">
              Edit
            </Button>
          </Link>
        )}
        <Button
          onClick={handleJoinMeeting}
          disabled={isJoining || (!isLive && !isCreator)}
          className={isLive ? "bg-green-600 hover:bg-green-700" : ""}
        >
          {isJoining ? "Joining..." : isLive ? "Join Now" : isPending ? "Not Started Yet" : "Meeting Ended"}
        </Button>
      </CardFooter>
    </Card>
  )
}
