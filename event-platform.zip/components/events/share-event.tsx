"use client"

import { useState } from "react"
import { Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"

interface ShareEventProps {
  event: any
}

export function ShareEvent({ event }: ShareEventProps) {
  const [isOpen, setIsOpen] = useState(false)

  const shareUrl = typeof window !== "undefined" ? window.location.href : ""

  const shareOptions = [
    {
      name: "Copy Link",
      action: () => {
        navigator.clipboard.writeText(shareUrl)
        toast({
          title: "Link copied",
          description: "Event link has been copied to clipboard",
        })
      },
    },
    {
      name: "Share on Twitter",
      action: () => {
        window.open(
          `https://twitter.com/intent/tweet?text=Check out this event: ${event.title}&url=${encodeURIComponent(
            shareUrl,
          )}`,
          "_blank",
        )
      },
    },
    {
      name: "Share on Facebook",
      action: () => {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, "_blank")
      },
    },
    {
      name: "Share on LinkedIn",
      action: () => {
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, "_blank")
      },
    },
  ]

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button size="icon" variant="secondary">
          <Share2 className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {shareOptions.map((option) => (
          <DropdownMenuItem
            key={option.name}
            onClick={() => {
              option.action()
              setIsOpen(false)
            }}
          >
            {option.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
