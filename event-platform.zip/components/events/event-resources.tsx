"use client"

import { useEffect, useState } from "react"
import { Download, FileText } from "lucide-react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"

interface EventResourcesProps {
  eventId: string
}

interface Resource {
  id: string
  name: string
  file_url: string
}

export function EventResources({ eventId }: EventResourcesProps) {
  const [resources, setResources] = useState<Resource[] | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClientComponentClient()

  useEffect(() => {
    async function fetchResources() {
      try {
        setLoading(true)
        const { data, error } = await supabase.from("event_resources").select("*").eq("event_id", eventId)

        if (error) {
          console.error("Error fetching resources:", error)
          return
        }

        setResources(data || [])
      } catch (error) {
        console.error("Error fetching resources:", error)
      } finally {
        setLoading(false)
      }
    }

    if (eventId) {
      fetchResources()
    }
  }, [eventId, supabase])

  if (loading) {
    return (
      <div>
        <h2 className="text-xl font-bold mb-4">Event Resources</h2>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="flex items-center justify-between rounded-lg border p-3">
              <div className="flex items-center">
                <Skeleton className="h-5 w-5 mr-3" />
                <Skeleton className="h-4 w-40" />
              </div>
              <Skeleton className="h-9 w-24" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (!resources || resources.length === 0) {
    return (
      <div>
        <h2 className="text-xl font-bold mb-4">Event Resources</h2>
        <p className="text-muted-foreground">No resources available for this event.</p>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Event Resources</h2>
      <div className="space-y-3">
        {resources.map((resource) => (
          <div key={resource.id} className="flex items-center justify-between rounded-lg border p-3">
            <div className="flex items-center">
              <FileText className="h-5 w-5 mr-3 text-muted-foreground" />
              <span>{resource.name}</span>
            </div>
            <a href={resource.file_url} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </a>
          </div>
        ))}
      </div>
    </div>
  )
}
