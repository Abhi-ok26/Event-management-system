"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { CalendarDays, Clock, MapPin, Ticket } from "lucide-react"
import { formatCurrency, formatDate, formatTime } from "@/lib/utils"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface TicketPurchaseSectionProps {
  eventId: string
}

export function TicketPurchaseSection({ eventId }: TicketPurchaseSectionProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [ticketTypes, setTicketTypes] = useState<any[]>([])
  const [event, setEvent] = useState<any>(null)
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    async function fetchData() {
      try {
        // Get event details
        const { data: eventData, error: eventError } = await supabase
          .from("events")
          .select("*")
          .eq("id", eventId)
          .single()

        if (eventError) throw eventError

        // Get ticket types for this event
        const { data: ticketTypesData, error: ticketTypesError } = await supabase
          .from("ticket_types")
          .select("*")
          .eq("event_id", eventId)
          .order("price", { ascending: true })

        if (ticketTypesError) throw ticketTypesError

        setEvent(eventData)
        setTicketTypes(ticketTypesData || [])
      } catch (error) {
        console.error("Error fetching ticket data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [eventId, supabase])

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-3/4" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-full" />
        </CardFooter>
      </Card>
    )
  }

  if (!event) {
    return null
  }

  const eventDate = new Date(event.start_time)
  const isUpcoming = eventDate > new Date()
  const hasTickets = ticketTypes && ticketTypes.length > 0

  return (
    <Card>
      <CardHeader>
        <CardTitle>Get Tickets</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center text-sm">
          <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>{formatDate(event.start_time)}</span>
        </div>
        <div className="flex items-center text-sm">
          <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>
            {formatTime(event.start_time)} - {formatTime(event.end_time)}
          </span>
        </div>
        <div className="flex items-center text-sm">
          <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
          <span>{event.location || "Virtual Event"}</span>
        </div>

        {hasTickets && (
          <div className="space-y-2 pt-2">
            <p className="text-sm font-medium">Available Tickets:</p>
            <div className="space-y-2">
              {ticketTypes.map((ticket) => (
                <div key={ticket.id} className="flex items-center justify-between rounded-md border p-2 text-sm">
                  <div>
                    <p className="font-medium">{ticket.name}</p>
                    {ticket.description && <p className="text-xs text-muted-foreground">{ticket.description}</p>}
                  </div>
                  <p className="font-medium">{formatCurrency(ticket.price)}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {!hasTickets && (
          <div className="rounded-md bg-yellow-50 p-3 text-sm text-yellow-800">
            <p>No tickets are currently available for this event.</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        {isUpcoming && hasTickets ? (
          <Link href={`/events/${eventId}/buy-ticket`} className="w-full">
            <Button className="w-full" size="lg">
              <Ticket className="mr-2 h-4 w-4" />
              Buy Tickets Now
            </Button>
          </Link>
        ) : !isUpcoming ? (
          <Button className="w-full" disabled>
            Event has already started
          </Button>
        ) : (
          <Button className="w-full" disabled>
            Tickets unavailable
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
