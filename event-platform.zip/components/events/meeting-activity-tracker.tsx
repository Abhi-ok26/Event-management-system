"use client"

import { useEffect, useState } from "react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"

interface MeetingActivityTrackerProps {
  meetingRoomId: string
  onActivityUpdate?: (data: { activeParticipants: number }) => void
}

export function MeetingActivityTracker({ meetingRoomId, onActivityUpdate }: MeetingActivityTrackerProps) {
  const [activeParticipants, setActiveParticipants] = useState(0)
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    // Initial fetch of active participants
    const fetchActiveParticipants = async () => {
      const { data, error } = await supabase
        .from("meeting_participants")
        .select("*")
        .eq("meeting_room_id", meetingRoomId)
        .is("left_at", null)

      if (!error && data) {
        setActiveParticipants(data.length)
        onActivityUpdate?.({ activeParticipants: data.length })
      }
    }

    fetchActiveParticipants()

    // Subscribe to changes
    const channel = supabase
      .channel(`meeting-activity-${meetingRoomId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "meeting_participants",
          filter: `meeting_room_id=eq.${meetingRoomId}`,
        },
        () => {
          fetchActiveParticipants()
        },
      )
      .subscribe()

    return () => {
      channel.unsubscribe()
    }
  }, [meetingRoomId, onActivityUpdate, supabase])

  // This component doesn't render anything visible
  // It just tracks activity and calls the onActivityUpdate callback
  return null
}
