"use client"

import type React from "react"

import { useRouter, useSearchParams } from "next/navigation"
import { Search, SlidersHorizontal } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface EventFilterProps {
  categories: string[]
}

export function EventFilter({ categories }: EventFilterProps) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const currentSearch = searchParams.get("search") || ""
  const currentCategory = searchParams.get("category") || "all"
  const currentSort = searchParams.get("sort") || "date-asc"

  const createQueryString = (params: Record<string, string | null>) => {
    const newSearchParams = new URLSearchParams(searchParams.toString())

    Object.entries(params).forEach(([key, value]) => {
      if (value === null) {
        newSearchParams.delete(key)
      } else {
        newSearchParams.set(key, value)
      }
    })

    return newSearchParams.toString()
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const search = formData.get("search") as string

    router.push(`/events?${createQueryString({ search: search || null })}`)
  }

  const handleCategoryChange = (value: string) => {
    router.push(`/events?${createQueryString({ category: value === "all" ? null : value })}`)
  }

  const handleSortChange = (value: string) => {
    router.push(`/events?${createQueryString({ sort: value })}`)
  }

  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end">
      <form onSubmit={handleSearch} className="flex-1">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            name="search"
            placeholder="Search events..."
            defaultValue={currentSearch}
            className="pl-8"
          />
        </div>
      </form>
      <div className="flex gap-2">
        <Select defaultValue={currentCategory} onValueChange={handleCategoryChange}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select defaultValue={currentSort} onValueChange={handleSortChange}>
          <SelectTrigger className="w-[160px]">
            <SlidersHorizontal className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date-asc">Date (Ascending)</SelectItem>
            <SelectItem value="date-desc">Date (Descending)</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
