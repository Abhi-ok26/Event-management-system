import Link from "next/link"
import Image from "next/image"
import { formatDate } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import { getSupabaseServerClient } from "@/lib/supabase/server"

interface SimilarEventsProps {
  currentEventId: string
  category?: string
}

export async function SimilarEvents({ currentEventId, category }: SimilarEventsProps) {
  const supabase = getSupabaseServerClient()

  // Fetch similar events (same category, excluding current event)
  let query = supabase.from("events").select("*").neq("id", currentEventId).limit(3)

  // Add category filter if provided
  if (category) {
    query = query.eq("category", category)
  }

  // Add published filter
  query = query.eq("is_published", true)

  const { data: events, error } = await query

  if (error) {
    console.error("Error fetching similar events:", error)
    return <div className="text-sm text-muted-foreground">Unable to load similar events</div>
  }

  if (!events || events.length === 0) {
    return <div className="text-sm text-muted-foreground">No similar events found</div>
  }

  return (
    <div className="space-y-4">
      {events.map((event) => (
        <Link key={event.id} href={`/events/${event.id}`}>
          <Card className="overflow-hidden hover:shadow-md transition-shadow">
            <div className="flex">
              <div className="h-20 w-20 relative flex-shrink-0">
                <Image
                  src={event.thumbnail_url || "/placeholder.svg?height=80&width=80&query=event"}
                  alt={event.title}
                  fill
                  className="object-cover"
                />
              </div>
              <CardContent className="p-3">
                <h3 className="font-semibold line-clamp-1">{event.title}</h3>
                <p className="text-xs text-muted-foreground">{formatDate(event.start_time)}</p>
              </CardContent>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  )
}
