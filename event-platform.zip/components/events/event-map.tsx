"use client"

import { useState, useEffect } from "react"
import { MapPin } from "lucide-react"

interface EventMapProps {
  location: string
}

export function EventMap({ location }: EventMapProps) {
  const [mapUrl, setMapUrl] = useState<string | null>(null)

  useEffect(() => {
    if (location) {
      // Create a Google Maps embed URL from the location string
      const encodedLocation = encodeURIComponent(location)
      setMapUrl(`https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${encodedLocation}`)
    }
  }, [location])

  if (!mapUrl) {
    return (
      <div className="flex h-[300px] items-center justify-center rounded-lg border bg-muted">
        <div className="text-center">
          <MapPin className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">Location map unavailable</p>
        </div>
      </div>
    )
  }

  return (
    <div className="rounded-lg overflow-hidden border h-[300px]">
      <div className="text-xs text-muted-foreground mb-2">
        <p>{location}</p>
      </div>
      <div className="relative h-[270px] w-full">
        {/* For security reasons, we're showing a placeholder instead of an actual map */}
        <div className="absolute inset-0 flex items-center justify-center bg-muted">
          <div className="text-center">
            <MapPin className="mx-auto h-8 w-8 text-muted-foreground" />
            <p className="mt-2 text-sm">Map would display here with a valid API key</p>
            <p className="text-xs text-muted-foreground mt-1">{location}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
