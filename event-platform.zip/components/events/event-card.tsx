import Image from "next/image"
import Link from "next/link"
import { format } from "date-fns"
import { CalendarIcon, MapPinIcon } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface EventCardProps {
  event: any
  className?: string
}

export function EventCard({ event, className }: EventCardProps) {
  if (!event) {
    return null
  }

  return (
    <Card className={`overflow-hidden hover:shadow-md transition-shadow ${className}`}>
      <Link href={`/events/${event.id}`}>
        <div className="aspect-video relative">
          {event.thumbnail_url ? (
            <Image src={event.thumbnail_url || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
          ) : (
            <div className="w-full h-full bg-muted flex items-center justify-center">
              <span className="text-muted-foreground">No image</span>
            </div>
          )}
          {event.category && (
            <Badge variant="secondary" className="absolute top-2 left-2">
              {event.category}
            </Badge>
          )}
          {!event.is_published && (
            <div className="absolute right-2 top-2 rounded-full bg-yellow-100 px-2 py-1 text-xs font-medium text-yellow-800">
              Unpublished
            </div>
          )}
        </div>
      </Link>
      <CardHeader className="p-4 pb-2">
        <Link href={`/events/${event.id}`} className="hover:underline">
          <h3 className="text-xl font-bold line-clamp-1">{event.title}</h3>
        </Link>
      </CardHeader>
      <CardContent className="p-4 pt-0 space-y-2">
        <p className="text-muted-foreground text-sm line-clamp-2">{event.description}</p>
        <div className="flex items-center text-sm text-muted-foreground">
          <CalendarIcon className="mr-1 h-4 w-4" />
          <span>{format(new Date(event.start_time), "PPP")}</span>
        </div>
        {event.location && (
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPinIcon className="mr-1 h-4 w-4" />
            <span className="line-clamp-1">{event.location}</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link href={`/events/${event.id}`} className="w-full">
          <Button className="w-full">View Details</Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
