"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface EventCountdownProps {
  startTime: string
  title?: string
}

export function EventCountdown({ startTime, title = "Countdown" }: EventCountdownProps) {
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft(startTime))

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft(startTime))
    }, 1000)

    return () => clearTimeout(timer)
  })

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {timeLeft.isExpired ? (
          <p className="text-center font-semibold">Event has started!</p>
        ) : (
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="flex flex-col">
              <span className="text-2xl font-bold">{timeLeft.days}</span>
              <span className="text-xs text-muted-foreground">Days</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold">{timeLeft.hours}</span>
              <span className="text-xs text-muted-foreground">Hours</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold">{timeLeft.minutes}</span>
              <span className="text-xs text-muted-foreground">Minutes</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold">{timeLeft.seconds}</span>
              <span className="text-xs text-muted-foreground">Seconds</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function calculateTimeLeft(targetDate: string) {
  const difference = +new Date(targetDate) - +new Date()

  if (difference <= 0) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      isExpired: true,
    }
  }

  return {
    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((difference / 1000 / 60) % 60),
    seconds: Math.floor((difference / 1000) % 60),
    isExpired: false,
  }
}
