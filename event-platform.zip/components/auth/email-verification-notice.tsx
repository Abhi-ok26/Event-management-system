"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { toast } from "@/components/ui/use-toast"

interface EmailVerificationNoticeProps {
  email: string
}

export function EmailVerificationNotice({ email }: EmailVerificationNoticeProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const resendVerificationEmail = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
      })

      if (error) throw error

      toast({
        title: "Verification email sent",
        description: "Please check your inbox for the verification link.",
      })
    } catch (error: any) {
      setError(error.message || "Failed to resend verification email")
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Email Verification Required</CardTitle>
        <CardDescription>Please verify your email address to continue</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="text-center space-y-4">
          <p>
            We've sent a verification email to <strong>{email}</strong>. Please check your inbox and click the
            verification link to activate your account.
          </p>

          <div className="bg-muted p-4 rounded-md text-sm">
            <p className="font-medium mb-2">Haven't received the email?</p>
            <ul className="list-disc list-inside text-muted-foreground space-y-1">
              <li>Check your spam or junk folder</li>
              <li>Verify that you entered the correct email address</li>
              <li>Wait a few minutes for the email to arrive</li>
            </ul>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <Button onClick={resendVerificationEmail} disabled={isLoading} className="w-full">
          {isLoading ? "Sending..." : "Resend Verification Email"}
        </Button>
        <Button variant="outline" onClick={() => router.push("/auth/direct-signup")} className="w-full">
          Try Direct Signup Instead
        </Button>
      </CardFooter>
    </Card>
  )
}
