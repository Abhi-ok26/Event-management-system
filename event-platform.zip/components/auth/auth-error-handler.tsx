"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { toast } from "@/components/ui/use-toast"
import { AlertCircle, CheckCircle2, RefreshCw } from "lucide-react"

export function AuthErrorHandler() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [success, setSuccess] = useState(false)
  const searchParams = useSearchParams()
  const router = useRouter()

  // Get error details from URL
  const error = searchParams.get("error")
  const errorCode = searchParams.get("error_code")
  const errorDescription = searchParams.get("error_description")

  // Check if this is an OTP expired error
  const isOtpExpired = errorCode === "otp_expired"

  // Function to request a new confirmation email
  const requestNewConfirmation = async () => {
    if (!email) {
      toast({
        title: "Email required",
        description: "Please enter your email address to request a new confirmation link.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = getSupabaseBrowserClient()

      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
      })

      if (error) throw error

      setSuccess(true)
      toast({
        title: "Confirmation email sent",
        description: "Please check your inbox for a new confirmation link.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send confirmation email. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // If no error, don't render anything
  if (!error) return null

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-xl">Authentication Error</CardTitle>
        <CardDescription>
          {isOtpExpired ? "Your confirmation link has expired" : "There was a problem with authentication"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error: {errorCode}</AlertTitle>
          <AlertDescription>{errorDescription?.replace(/\+/g, " ") || "An unknown error occurred"}</AlertDescription>
        </Alert>

        {isOtpExpired && !success && (
          <div className="space-y-4">
            <p className="text-sm">
              Confirmation links are only valid for 24 hours. Please enter your email to request a new confirmation
              link.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
              <Button onClick={requestNewConfirmation} disabled={isLoading || !email} size="sm">
                {isLoading ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Sending
                  </>
                ) : (
                  "Resend"
                )}
              </Button>
            </div>
          </div>
        )}

        {success && (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Email Sent</AlertTitle>
            <AlertDescription className="text-green-700">
              A new confirmation email has been sent to {email}. Please check your inbox.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>

      <CardFooter>
        <Button variant="outline" className="w-full" onClick={() => router.push("/auth/login")}>
          Return to Login
        </Button>
      </CardFooter>
    </Card>
  )
}
