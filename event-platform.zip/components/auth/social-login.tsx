"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { Github, Mail } from "lucide-react"

export function SocialLogin() {
  const [isLoading, setIsLoading] = useState<string | null>(null)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  async function handleSocialLogin(provider: "github" | "google") {
    setIsLoading(provider)
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(null)
    }
  }

  async function handleMagicLink(email: string) {
    if (!email || !email.includes("@")) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      })
      return
    }

    setIsLoading("magic")
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error

      toast({
        title: "Magic link sent",
        description: "Check your email for a login link",
      })
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(null)
    }
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Quick Login Options</CardTitle>
        <CardDescription>Sign in quickly with your existing accounts</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button
          variant="outline"
          className="w-full"
          onClick={() => handleSocialLogin("github")}
          disabled={isLoading !== null}
        >
          <Github className="mr-2 h-4 w-4" />
          {isLoading === "github" ? "Signing in..." : "Continue with GitHub"}
        </Button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">Or</span>
          </div>
        </div>

        <div className="flex flex-col space-y-2">
          <div className="flex space-x-2">
            <input
              type="email"
              placeholder="email@example.com"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              id="magic-email"
            />
            <Button
              variant="outline"
              onClick={() => {
                const email = (document.getElementById("magic-email") as HTMLInputElement).value
                handleMagicLink(email)
              }}
              disabled={isLoading !== null}
            >
              <Mail className="h-4 w-4" />
            </Button>
          </div>
          <Button
            variant="ghost"
            className="text-xs"
            onClick={() => {
              const email = (document.getElementById("magic-email") as HTMLInputElement).value
              handleMagicLink(email)
            }}
            disabled={isLoading !== null}
          >
            {isLoading === "magic" ? "Sending..." : "Send magic link"}
          </Button>
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <p className="text-sm text-muted-foreground">No password required with these methods</p>
      </CardFooter>
    </Card>
  )
}
