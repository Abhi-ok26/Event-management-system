"use server"

import { getSupabaseServerClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createAccountDirectly(
  email: string,
  password: string,
  fullName: string,
  userType: "attendee" | "creator",
) {
  const supabase = getSupabaseServerClient()

  try {
    // Create user with email and password
    const { data: authData, error: signUpError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Mark email as confirmed
      user_metadata: {
        full_name: fullName,
        user_type: userType,
      },
    })

    if (signUpError) {
      return { success: false, error: signUpError.message }
    }

    if (!authData.user) {
      return { success: false, error: "Failed to create user" }
    }

    // Create profile in the database
    const { error: profileError } = await supabase.from("profiles").insert({
      id: authData.user.id,
      email,
      full_name: fullName,
      user_type: userType,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (profileError) {
      console.error("Error creating profile:", profileError)
    }

    revalidatePath("/")
    return { success: true, user: authData.user }
  } catch (error: any) {
    console.error("Direct auth error:", error)
    return { success: false, error: error.message || "An error occurred during account creation" }
  }
}
