"use server"

import { getSupabaseServerClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function verifyAccountWithOtp(email: string) {
  const supabase = getSupabaseServerClient()

  try {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        shouldCreateUser: false,
      },
    })

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to send verification code" }
  }
}

export async function confirmOtp(email: string, token: string) {
  const supabase = getSupabaseServerClient()

  try {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: "email",
    })

    if (error) {
      return { success: false, error: error.message }
    }

    revalidatePath("/")
    return { success: true, session: data.session }
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to verify code" }
  }
}
