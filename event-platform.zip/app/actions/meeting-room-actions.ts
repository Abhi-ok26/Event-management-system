"use server"

import { revalidatePath } from "next/cache"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function createMeetingRoom(formData: FormData) {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to create a meeting room" }
  }

  // Get form data
  const eventId = formData.get("eventId") as string
  const name = formData.get("name") as string
  const description = formData.get("description") as string
  const meetingLink = formData.get("meetingLink") as string
  const password = formData.get("password") as string
  const startTime = formData.get("startTime") as string
  const endTime = formData.get("endTime") as string
  const maxParticipants = Number.parseInt(formData.get("maxParticipants") as string) || null

  // Validate form data
  if (!eventId || !name || !startTime || !endTime) {
    return { error: "Missing required fields" }
  }

  // Check if user is the creator of the event
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  if (eventError || !event) {
    return { error: "Event not found" }
  }

  if (event.creator_id !== session.user.id) {
    return { error: "You do not have permission to create a meeting room for this event" }
  }

  // Create meeting room
  const { data, error } = await supabase
    .from("meeting_rooms")
    .insert({
      event_id: eventId,
      name,
      description,
      meeting_link: meetingLink,
      password,
      start_time: startTime,
      end_time: endTime,
      is_active: true,
      max_participants: maxParticipants,
    })
    .select()
    .single()

  if (error) {
    console.error("Error creating meeting room:", error)
    return { error: error.message }
  }

  revalidatePath(`/dashboard/creator/events/${eventId}`)
  revalidatePath(`/events/${eventId}`)

  return { success: true, data }
}

export async function updateMeetingRoom(formData: FormData) {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to update a meeting room" }
  }

  // Get form data
  const meetingRoomId = formData.get("meetingRoomId") as string
  const eventId = formData.get("eventId") as string
  const name = formData.get("name") as string
  const description = formData.get("description") as string
  const meetingLink = formData.get("meetingLink") as string
  const password = formData.get("password") as string
  const startTime = formData.get("startTime") as string
  const endTime = formData.get("endTime") as string
  const maxParticipants = Number.parseInt(formData.get("maxParticipants") as string) || null
  const isActive = formData.get("isActive") === "true"

  // Validate form data
  if (!meetingRoomId || !eventId || !name || !startTime || !endTime) {
    return { error: "Missing required fields" }
  }

  // Check if user is the creator of the event
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  if (eventError || !event) {
    return { error: "Event not found" }
  }

  if (event.creator_id !== session.user.id) {
    return { error: "You do not have permission to update this meeting room" }
  }

  // Update meeting room
  const { data, error } = await supabase
    .from("meeting_rooms")
    .update({
      name,
      description,
      meeting_link: meetingLink,
      password,
      start_time: startTime,
      end_time: endTime,
      is_active: isActive,
      max_participants: maxParticipants,
      updated_at: new Date().toISOString(),
    })
    .eq("id", meetingRoomId)
    .select()
    .single()

  if (error) {
    console.error("Error updating meeting room:", error)
    return { error: error.message }
  }

  revalidatePath(`/dashboard/creator/events/${eventId}`)
  revalidatePath(`/events/${eventId}`)

  return { success: true, data }
}

export async function deleteMeetingRoom(meetingRoomId: string, eventId: string) {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to delete a meeting room" }
  }

  // Check if user is the creator of the event
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  if (eventError || !event) {
    return { error: "Event not found" }
  }

  if (event.creator_id !== session.user.id) {
    return { error: "You do not have permission to delete this meeting room" }
  }

  // Delete meeting room
  const { error } = await supabase.from("meeting_rooms").delete().eq("id", meetingRoomId)

  if (error) {
    console.error("Error deleting meeting room:", error)
    return { error: error.message }
  }

  revalidatePath(`/dashboard/creator/events/${eventId}`)
  revalidatePath(`/events/${eventId}`)

  return { success: true }
}

export async function joinMeetingRoom(meetingRoomId: string, eventId: string) {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to join a meeting room" }
  }

  // Check if user has a ticket for this event
  const { data: ticket, error: ticketError } = await supabase
    .from("tickets")
    .select("*")
    .eq("event_id", eventId)
    .eq("attendee_id", session.user.id)
    .single()

  // Also allow the event creator to join
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  const isCreator = event?.creator_id === session.user.id

  if ((ticketError && !isCreator) || (!ticket && !isCreator)) {
    return { error: "You do not have a ticket for this event" }
  }

  // Check if meeting room exists and is active
  const { data: meetingRoom, error: meetingRoomError } = await supabase
    .from("meeting_rooms")
    .select("*")
    .eq("id", meetingRoomId)
    .eq("event_id", eventId)
    .eq("is_active", true)
    .single()

  if (meetingRoomError || !meetingRoom) {
    return { error: "Meeting room not found or inactive" }
  }

  // Check if meeting is currently happening
  const now = new Date()
  const startTime = new Date(meetingRoom.start_time)
  const endTime = new Date(meetingRoom.end_time)

  if (now < startTime) {
    return { error: "Meeting has not started yet" }
  }

  if (now > endTime) {
    return { error: "Meeting has already ended" }
  }

  // Record participant joining
  const { data: participant, error: participantError } = await supabase
    .from("meeting_participants")
    .upsert({
      meeting_room_id: meetingRoomId,
      user_id: session.user.id,
      joined_at: now.toISOString(),
      left_at: null,
      is_presenter: isCreator, // Creator is automatically a presenter
    })
    .select()

  if (participantError) {
    console.error("Error recording participant:", participantError)
    return { error: participantError.message }
  }

  return { success: true, meetingRoom, isPresenter: isCreator }
}

export async function leaveMeetingRoom(meetingRoomId: string) {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to leave a meeting room" }
  }

  // Update participant record
  const { error } = await supabase
    .from("meeting_participants")
    .update({
      left_at: new Date().toISOString(),
    })
    .eq("meeting_room_id", meetingRoomId)
    .eq("user_id", session.user.id)
    .is("left_at", null)

  if (error) {
    console.error("Error leaving meeting room:", error)
    return { error: error.message }
  }

  return { success: true }
}
