"use server"

import { getSupabaseServerClient } from "@/lib/supabase/server"
import { calculateMeetingAnalytics } from "@/lib/analytics-utils"
import type { MeetingAnalytics } from "@/lib/analytics-utils"

export async function getMeetingRoomAnalytics(
  meetingRoomId: string,
  eventId: string,
): Promise<{
  data?: MeetingAnalytics
  error?: string
}> {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to view analytics" }
  }

  // Check if user is the creator of the event
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  if (eventError || !event) {
    return { error: "Event not found" }
  }

  if (event.creator_id !== session.user.id) {
    return { error: "You do not have permission to view analytics for this event" }
  }

  // Get meeting room details
  const { data: meetingRoom, error: meetingRoomError } = await supabase
    .from("meeting_rooms")
    .select("*")
    .eq("id", meetingRoomId)
    .eq("event_id", eventId)
    .single()

  if (meetingRoomError || !meetingRoom) {
    return { error: "Meeting room not found" }
  }

  // Get all participants for this meeting room
  const { data: participants, error: participantsError } = await supabase
    .from("meeting_participants")
    .select(`
      *,
      profiles:user_id(*)
    `)
    .eq("meeting_room_id", meetingRoomId)

  if (participantsError) {
    console.error("Error fetching participants:", participantsError)
    return { error: "Failed to fetch participant data" }
  }

  // Calculate analytics
  const analytics = calculateMeetingAnalytics(participants || [], meetingRoom.start_time, meetingRoom.end_time)

  return { data: analytics }
}

export async function getEventMeetingAnalytics(eventId: string): Promise<{
  data?: {
    totalMeetings: number
    totalUniqueParticipants: number
    meetingAnalytics: {
      id: string
      name: string
      startTime: string
      endTime: string
      participantCount: number
    }[]
  }
  error?: string
}> {
  const supabase = getSupabaseServerClient()

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) {
    return { error: "You must be logged in to view analytics" }
  }

  // Check if user is the creator of the event
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("creator_id")
    .eq("id", eventId)
    .single()

  if (eventError || !event) {
    return { error: "Event not found" }
  }

  if (event.creator_id !== session.user.id) {
    return { error: "You do not have permission to view analytics for this event" }
  }

  // Get all meeting rooms for this event
  const { data: meetingRooms, error: meetingRoomsError } = await supabase
    .from("meeting_rooms")
    .select("*")
    .eq("event_id", eventId)

  if (meetingRoomsError) {
    console.error("Error fetching meeting rooms:", meetingRoomsError)
    return { error: "Failed to fetch meeting room data" }
  }

  if (!meetingRooms || meetingRooms.length === 0) {
    return {
      data: {
        totalMeetings: 0,
        totalUniqueParticipants: 0,
        meetingAnalytics: [],
      },
    }
  }

  // Get all participants for all meeting rooms in this event
  const { data: allParticipants, error: participantsError } = await supabase
    .from("meeting_participants")
    .select(`
      *,
      profiles:user_id(*)
    `)
    .in(
      "meeting_room_id",
      meetingRooms.map((room) => room.id),
    )

  if (participantsError) {
    console.error("Error fetching participants:", participantsError)
    return { error: "Failed to fetch participant data" }
  }

  // Calculate unique participants across all meetings
  const uniqueParticipants = new Set((allParticipants || []).map((p) => p.user_id))

  // Calculate per-meeting analytics
  const meetingAnalytics = meetingRooms.map((room) => {
    const roomParticipants = (allParticipants || []).filter((p) => p.meeting_room_id === room.id)
    const uniqueRoomParticipants = new Set(roomParticipants.map((p) => p.user_id))

    return {
      id: room.id,
      name: room.name,
      startTime: room.start_time,
      endTime: room.end_time,
      participantCount: uniqueRoomParticipants.size,
    }
  })

  return {
    data: {
      totalMeetings: meetingRooms.length,
      totalUniqueParticipants: uniqueParticipants.size,
      meetingAnalytics,
    },
  }
}
