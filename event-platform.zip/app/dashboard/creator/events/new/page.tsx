import { redirect } from "next/navigation"
import { getSupabaseServerClient } from "@/lib/supabase/server"

import { EventForm } from "@/components/dashboard/creator/event-form"

export default async function NewEventPage() {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold tracking-tight">Create New Event</h1>
        <div className="rounded-lg border p-6">
          <EventForm />
        </div>
      </div>
    </div>
  )
}
