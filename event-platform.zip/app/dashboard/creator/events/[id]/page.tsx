import Link from "next/link"
import Image from "next/image"
import { notFound, redirect } from "next/navigation"
import { CalendarDays, Clock, Edit, Plus, Ticket, Upload, Users } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { formatCurrency, formatDate, formatTime } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface EventDetailPageProps {
  params: {
    id: string
  }
}

export default async function EventDetailPage({ params }: EventDetailPageProps) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch event details
  const { data: event } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.id)
    .eq("creator_id", session.user.id)
    .single()

  if (!event) {
    notFound()
  }

  // Fetch ticket types
  const { data: ticketTypes } = await supabase
    .from("ticket_types")
    .select("*")
    .eq("event_id", event.id)
    .order("price", { ascending: true })

  // Fetch ticket sales
  const { data: tickets } = await supabase
    .from("tickets")
    .select(`
      *,
      profiles:attendee_id(*)
    `)
    .eq("event_id", event.id)

  // Fetch event resources
  const { data: resources } = await supabase.from("event_resources").select("*").eq("event_id", event.id)

  // Fetch meeting room settings
  const { data: meetingRoom } = await supabase.from("meeting_rooms").select("*").eq("event_id", event.id).single()

  // Calculate total sales
  const totalSales = tickets
    ? tickets.reduce((sum, ticket) => {
        const ticketType = ticketTypes?.find((type) => type.id === ticket.ticket_type_id)
        return sum + (ticketType?.price || 0)
      }, 0)
    : 0

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <h1 className="text-3xl font-bold tracking-tight">{event.title}</h1>
          <div className="flex flex-col space-y-2 sm:flex-row sm:space-x-2 sm:space-y-0">
            <Link href={`/dashboard/creator/events/${event.id}/edit`}>
              <Button variant="outline">
                <Edit className="mr-2 h-4 w-4" />
                Edit Event
              </Button>
            </Link>
            <Link href={`/dashboard/creator/events/${event.id}/publish`}>
              <Button disabled={event.is_published}>{event.is_published ? "Published" : "Publish Event"}</Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <Card>
              <div className="relative h-[200px] w-full">
                <Image
                  src={event.thumbnail_url || "/placeholder.svg?height=200&width=800&query=event"}
                  alt={event.title}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <CardTitle>{event.title}</CardTitle>
                <CardDescription>{event.is_published ? "Published" : "Draft"}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col space-y-2">
                  <div className="flex items-center">
                    <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{formatDate(event.start_time)}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>
                      {formatTime(event.start_time)} - {formatTime(event.end_time)}
                    </span>
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="font-semibold">Description</h3>
                  <p className="mt-2 text-sm">{event.description}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Event Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm">Total Tickets Sold:</span>
                  <span className="font-semibold">{tickets?.length || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Total Sales:</span>
                  <span className="font-semibold">{formatCurrency(totalSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Ticket Types:</span>
                  <span className="font-semibold">{ticketTypes?.length || 0}</span>
                </div>
              </CardContent>
              <CardFooter>
                <Link href={`/dashboard/creator/events/${event.id}/tickets/new`} className="w-full">
                  <Button className="w-full">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Ticket Type
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Meeting Room</CardTitle>
              </CardHeader>
              <CardContent>
                {meetingRoom ? (
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Room Type:</span>
                      <span className="font-semibold capitalize">{meetingRoom.room_type}</span>
                    </div>
                    {meetingRoom.room_url && (
                      <div className="flex justify-between">
                        <span className="text-sm">Room URL:</span>
                        <Link href={meetingRoom.room_url} className="text-primary underline">
                          Open
                        </Link>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No meeting room configured yet.</p>
                )}
              </CardContent>
              <CardFooter>
                <Link href={`/dashboard/creator/events/${event.id}/meeting-room`} className="w-full">
                  <Button variant="outline" className="w-full">
                    {meetingRoom ? "Edit" : "Setup"} Meeting Room
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="tickets" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="tickets">Tickets & Attendees</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="tickets" className="space-y-6 mt-6">
            <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
              <h2 className="text-xl font-bold">Ticket Types</h2>
              <Link href={`/dashboard/creator/events/${event.id}/tickets/new`}>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Ticket Type
                </Button>
              </Link>
            </div>

            {ticketTypes && ticketTypes.length > 0 ? (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {ticketTypes.map((ticketType) => (
                  <Card key={ticketType.id}>
                    <CardHeader>
                      <CardTitle>{ticketType.name}</CardTitle>
                      <CardDescription>
                        {ticketType.is_early_bird && "Early Bird • "}
                        {ticketType.is_vip && "VIP • "}
                        {formatCurrency(ticketType.price)}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">{ticketType.description}</p>
                      {ticketType.quantity && <p className="text-sm mt-2">Quantity: {ticketType.quantity}</p>}
                    </CardContent>
                    <CardFooter>
                      <Link
                        href={`/dashboard/creator/events/${event.id}/tickets/${ticketType.id}/edit`}
                        className="w-full"
                      >
                        <Button variant="outline" size="sm" className="w-full">
                          Edit
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-6">
                  <Ticket className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-semibold">No Ticket Types</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    You haven't created any ticket types for this event yet.
                  </p>
                  <Link href={`/dashboard/creator/events/${event.id}/tickets/new`} className="mt-4 inline-block">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Ticket Type
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}

            <div className="mt-8">
              <h2 className="text-xl font-bold mb-4">Attendees</h2>

              {tickets && tickets.length > 0 ? (
                <div className="rounded-md border">
                  <div className="grid grid-cols-4 gap-4 p-4 font-medium border-b">
                    <div>Name</div>
                    <div>Ticket Type</div>
                    <div>Purchase Date</div>
                    <div>Status</div>
                  </div>
                  <div className="divide-y">
                    {tickets.map((ticket) => {
                      const ticketType = ticketTypes?.find((type) => type.id === ticket.ticket_type_id)
                      return (
                        <div key={ticket.id} className="grid grid-cols-4 gap-4 p-4">
                          <div>{ticket.profiles?.full_name}</div>
                          <div>{ticketType?.name}</div>
                          <div>{formatDate(ticket.purchase_time)}</div>
                          <div>
                            {ticket.is_used ? (
                              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                                Used
                              </span>
                            ) : (
                              <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                                Valid
                              </span>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-6">
                    <Users className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-4 text-lg font-semibold">No Attendees</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      No one has purchased tickets for this event yet.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6 mt-6">
            <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
              <h2 className="text-xl font-bold">Event Resources</h2>
              <Link href={`/dashboard/creator/events/${event.id}/resources/new`}>
                <Button size="sm">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Resource
                </Button>
              </Link>
            </div>

            {resources && resources.length > 0 ? (
              <div className="rounded-md border">
                <div className="grid grid-cols-3 gap-4 p-4 font-medium border-b">
                  <div>Name</div>
                  <div>Type</div>
                  <div>Actions</div>
                </div>
                <div className="divide-y">
                  {resources.map((resource) => {
                    const fileExtension = resource.file_url.split(".").pop()?.toLowerCase()
                    const fileType =
                      fileExtension === "pdf"
                        ? "PDF Document"
                        : fileExtension === "ppt" || fileExtension === "pptx"
                          ? "Presentation"
                          : fileExtension === "doc" || fileExtension === "docx"
                            ? "Document"
                            : "File"

                    return (
                      <div key={resource.id} className="grid grid-cols-3 gap-4 p-4">
                        <div>{resource.name}</div>
                        <div>{fileType}</div>
                        <div>
                          <Link href={resource.file_url} target="_blank">
                            <Button variant="outline" size="sm">
                              Download
                            </Button>
                          </Link>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-6">
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-semibold">No Resources</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    You haven't uploaded any resources for this event yet.
                  </p>
                  <Link href={`/dashboard/creator/events/${event.id}/resources/new`} className="mt-4 inline-block">
                    <Button>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Resource
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
