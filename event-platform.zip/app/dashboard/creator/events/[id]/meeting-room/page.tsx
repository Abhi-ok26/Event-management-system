import { notFound, redirect } from "next/navigation"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { MeetingRoomForm } from "@/components/dashboard/creator/meeting-room-form"
import type { MeetingRoom } from "@/lib/types"

interface MeetingRoomPageProps {
  params: {
    id: string
  }
}

export default async function MeetingRoomPage({ params }: MeetingRoomPageProps) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch event details
  const { data: event } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.id)
    .eq("creator_id", session.user.id)
    .single()

  if (!event) {
    notFound()
  }

  // Fetch existing meeting room if any
  const { data: meetingRoom } = await supabase
    .from("meeting_rooms")
    .select("*")
    .eq("event_id", params.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .single()

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold tracking-tight">
          {meetingRoom ? "Edit Meeting Room" : "Create Meeting Room"}
        </h1>
        <div className="rounded-lg border p-6">
          <MeetingRoomForm
            eventId={params.id}
            meetingRoom={meetingRoom as MeetingRoom}
            eventStartTime={event.start_time}
            eventEndTime={event.end_time}
          />
        </div>
      </div>
    </div>
  )
}
