import { notFound, redirect } from "next/navigation"
import { CalendarCheck, Check } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PublishEventForm } from "@/components/dashboard/creator/publish-event-form"

interface PublishEventPageProps {
  params: {
    id: string
  }
}

export default async function PublishEventPage({ params }: PublishEventPageProps) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch event details
  const { data: event } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.id)
    .eq("creator_id", session.user.id)
    .single()

  if (!event) {
    notFound()
  }

  // If already published, redirect to event page
  if (event.is_published) {
    redirect(`/dashboard/creator/events/${event.id}`)
  }

  // Check if event has ticket types
  const { data: ticketTypes, count } = await supabase
    .from("ticket_types")
    .select("*", { count: "exact" })
    .eq("event_id", event.id)

  const hasTickets = count && count > 0

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold tracking-tight">Publish Event</h1>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Ready to publish "{event.title}"?</CardTitle>
            <CardDescription>
              Publishing your event will make it visible to attendees and allow them to purchase tickets.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-2">
                <div className={`mt-0.5 rounded-full p-1 ${hasTickets ? "bg-green-100" : "bg-amber-100"}`}>
                  {hasTickets ? (
                    <Check className="h-4 w-4 text-green-600" />
                  ) : (
                    <span className="h-4 w-4 text-amber-600 flex items-center justify-center text-xs">!</span>
                  )}
                </div>
                <div>
                  <h3 className="font-medium">Ticket Types</h3>
                  <p className="text-sm text-muted-foreground">
                    {hasTickets
                      ? `You have ${count} ticket type${count === 1 ? "" : "s"} set up.`
                      : "You haven't set up any ticket types yet. We recommend adding at least one ticket type before publishing."}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" asChild>
              <a href={`/dashboard/creator/events/${event.id}`}>Go Back</a>
            </Button>
            <PublishEventForm eventId={event.id} />
          </CardFooter>
        </Card>

        {!hasTickets && (
          <Card>
            <CardHeader>
              <CardTitle>Add Ticket Types</CardTitle>
              <CardDescription>Create ticket types to allow attendees to register for your event.</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center py-6">
              <CalendarCheck className="h-16 w-16 text-muted-foreground" />
            </CardContent>
            <CardFooter>
              <Button className="w-full" asChild>
                <a href={`/dashboard/creator/events/${event.id}/tickets/new`}>Add Ticket Type</a>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}
