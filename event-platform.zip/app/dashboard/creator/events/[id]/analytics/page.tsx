import Link from "next/link"
import { redirect } from "next/navigation"
import { BarChart, ChevronRight } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { getEventMeetingAnalytics } from "@/app/actions/analytics-actions"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { EventAnalyticsSummary } from "@/components/dashboard/analytics/event-analytics-summary"
import { MeetingAnalyticsCard } from "@/components/dashboard/analytics/meeting-analytics-card"

interface EventAnalyticsPageProps {
  params: {
    id: string
  }
}

export default async function EventAnalyticsPage({ params }: EventAnalyticsPageProps) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch event details
  const { data: event } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.id)
    .eq("creator_id", session.user.id)
    .single()

  if (!event) {
    redirect("/dashboard/creator/events")
  }

  // Fetch analytics data
  const { data: analyticsData, error } = await getEventMeetingAnalytics(params.id)

  if (error) {
    console.error("Error fetching analytics:", error)
  }

  const { totalMeetings = 0, totalUniqueParticipants = 0, meetingAnalytics = [] } = analyticsData || {}

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
          <Link href="/dashboard/creator/events" className="hover:text-foreground">
            Events
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href={`/dashboard/creator/events/${params.id}`} className="hover:text-foreground">
            {event.title}
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span>Analytics</span>
        </div>

        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Meeting Analytics</h1>
          <p className="text-muted-foreground">
            View analytics and engagement data for all meeting rooms in this event.
          </p>
        </div>

        <EventAnalyticsSummary totalMeetings={totalMeetings} totalParticipants={totalUniqueParticipants} />

        <Separator />

        <div className="space-y-4">
          <h2 className="text-xl font-bold">Meeting Rooms</h2>

          {meetingAnalytics && meetingAnalytics.length > 0 ? (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {meetingAnalytics.map((meeting) => (
                <MeetingAnalyticsCard
                  key={meeting.id}
                  id={meeting.id}
                  eventId={params.id}
                  name={meeting.name}
                  startTime={meeting.startTime}
                  endTime={meeting.endTime}
                  participantCount={meeting.participantCount}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10 text-center">
                <BarChart className="h-10 w-10 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-semibold">No Meeting Rooms</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  You haven't created any meeting rooms for this event yet.
                </p>
                <Link href={`/dashboard/creator/events/${params.id}/meeting-room`} className="mt-4">
                  <Button>Create Meeting Room</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
