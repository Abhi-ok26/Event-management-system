import Link from "next/link"
import { redirect } from "next/navigation"
import { format } from "date-fns"
import { BarChart, ChevronRight } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { getMeetingRoomAnalytics } from "@/app/actions/analytics-actions"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { AnalyticsCharts } from "@/components/dashboard/analytics/analytics-charts"
import { AnalyticsSummary } from "@/components/dashboard/analytics/analytics-summary"
import { ParticipantDetailsTable } from "@/components/dashboard/analytics/participant-details-table"

interface MeetingAnalyticsPageProps {
  params: {
    id: string
    meetingId: string
  }
}

export default async function MeetingAnalyticsPage({ params }: MeetingAnalyticsPageProps) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch event details
  const { data: event } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.id)
    .eq("creator_id", session.user.id)
    .single()

  if (!event) {
    redirect("/dashboard/creator/events")
  }

  // Fetch meeting room details
  const { data: meetingRoom } = await supabase
    .from("meeting_rooms")
    .select("*")
    .eq("id", params.meetingId)
    .eq("event_id", params.id)
    .single()

  if (!meetingRoom) {
    redirect(`/dashboard/creator/events/${params.id}/analytics`)
  }

  // Fetch analytics data
  const { data: analyticsData, error } = await getMeetingRoomAnalytics(params.meetingId, params.id)

  if (error) {
    console.error("Error fetching analytics:", error)
    redirect(`/dashboard/creator/events/${params.id}/analytics`)
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
          <Link href="/dashboard/creator/events" className="hover:text-foreground">
            Events
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href={`/dashboard/creator/events/${params.id}`} className="hover:text-foreground">
            {event.title}
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href={`/dashboard/creator/events/${params.id}/analytics`} className="hover:text-foreground">
            Analytics
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span>{meetingRoom.name}</span>
        </div>

        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">{meetingRoom.name}</h1>
          <p className="text-muted-foreground">
            {format(new Date(meetingRoom.start_time), "PPP")} • {format(new Date(meetingRoom.start_time), "p")} -{" "}
            {format(new Date(meetingRoom.end_time), "p")}
          </p>
        </div>

        {analyticsData ? (
          <>
            <AnalyticsSummary analytics={analyticsData} />

            <Separator />

            <AnalyticsCharts analytics={analyticsData} />

            <Separator />

            <ParticipantDetailsTable participants={analyticsData.participantDetails} />
          </>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-10 text-center">
              <BarChart className="h-10 w-10 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No Analytics Data</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                There is no analytics data available for this meeting room yet.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
