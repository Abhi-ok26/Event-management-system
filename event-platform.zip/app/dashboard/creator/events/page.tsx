"use client"

import Link from "next/link"
import { redirect } from "next/navigation"
import { CalendarPlus, Filter, Search, SlidersHorizontal } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { formatDate } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default async function EventsManagementPage({
  searchParams,
}: { searchParams: { [key: string]: string | undefined } }) {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Get filter parameters
  const status = searchParams.status || "all"
  const sortBy = searchParams.sortBy || "created_at"
  const sortOrder = searchParams.sortOrder || "desc"
  const search = searchParams.search || ""

  // Build query
  let query = supabase
    .from("events")
    .select(`
      *,
      tickets(count),
      ticket_types(count)
    `)
    .eq("creator_id", session.user.id)

  // Apply filters
  if (status === "published") {
    query = query.eq("is_published", true)
  } else if (status === "draft") {
    query = query.eq("is_published", false)
  }

  // Apply search
  if (search) {
    query = query.ilike("title", `%${search}%`)
  }

  // Apply sorting
  query = query.order(sortBy as any, { ascending: sortOrder === "asc" })

  // Execute query
  const { data: events, error } = await query

  if (error) {
    console.error("Error fetching events:", error)
  }

  // Calculate stats
  const totalEvents = events?.length || 0
  const publishedEvents = events?.filter((event) => event.is_published).length || 0
  const draftEvents = events?.filter((event) => !event.is_published).length || 0
  const upcomingEvents = events?.filter((event) => new Date(event.start_time) > new Date()).length || 0

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <h1 className="text-3xl font-bold tracking-tight">Events Management</h1>
          <Link href="/dashboard/creator/events/new">
            <Button>
              <CalendarPlus className="mr-2 h-4 w-4" />
              Create Event
            </Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalEvents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Published</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{publishedEvents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Drafts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{draftEvents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Upcoming</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{upcomingEvents}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Events</CardTitle>
            <CardDescription>Manage all your events in one place.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
                <div className="flex w-full max-w-sm items-center space-x-2">
                  <Input
                    type="search"
                    placeholder="Search events..."
                    defaultValue={search}
                    onChange={(e) => {
                      const searchParams = new URLSearchParams(window.location.search)
                      if (e.target.value) {
                        searchParams.set("search", e.target.value)
                      } else {
                        searchParams.delete("search")
                      }
                      window.location.search = searchParams.toString()
                    }}
                  />
                  <Button type="submit" size="icon" variant="ghost">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center space-x-2">
                  <Select
                    defaultValue={status}
                    onValueChange={(value) => {
                      const searchParams = new URLSearchParams(window.location.search)
                      if (value !== "all") {
                        searchParams.set("status", value)
                      } else {
                        searchParams.delete("status")
                      }
                      window.location.search = searchParams.toString()
                    }}
                  >
                    <SelectTrigger className="w-[180px]">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>Status</SelectLabel>
                        <SelectItem value="all">All Events</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="draft">Drafts</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                  <Select
                    defaultValue={`${sortBy}-${sortOrder}`}
                    onValueChange={(value) => {
                      const [sortBy, sortOrder] = value.split("-")
                      const searchParams = new URLSearchParams(window.location.search)
                      searchParams.set("sortBy", sortBy)
                      searchParams.set("sortOrder", sortOrder)
                      window.location.search = searchParams.toString()
                    }}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SlidersHorizontal className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>Sort by</SelectLabel>
                        <SelectItem value="created_at-desc">Newest first</SelectItem>
                        <SelectItem value="created_at-asc">Oldest first</SelectItem>
                        <SelectItem value="title-asc">Title (A-Z)</SelectItem>
                        <SelectItem value="title-desc">Title (Z-A)</SelectItem>
                        <SelectItem value="start_time-asc">Start date (ascending)</SelectItem>
                        <SelectItem value="start_time-desc">Start date (descending)</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Event</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Tickets</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events && events.length > 0 ? (
                      events.map((event) => (
                        <TableRow key={event.id}>
                          <TableCell className="font-medium">
                            <Link href={`/dashboard/creator/events/${event.id}`} className="hover:underline">
                              {event.title}
                            </Link>
                          </TableCell>
                          <TableCell>{formatDate(event.start_time)}</TableCell>
                          <TableCell>
                            {event.is_published ? (
                              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                                Published
                              </span>
                            ) : (
                              <span className="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-800">
                                Draft
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            {event.tickets?.[0]?.count || 0} sold / {event.ticket_types?.[0]?.count || 0} types
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Link href={`/dashboard/creator/events/${event.id}`}>
                                <Button variant="outline" size="sm">
                                  View
                                </Button>
                              </Link>
                              <Link href={`/dashboard/creator/events/${event.id}/edit`}>
                                <Button variant="outline" size="sm">
                                  Edit
                                </Button>
                              </Link>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          No events found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
