import Link from "next/link"
import { redirect } from "next/navigation"
import { CalendarPlus, TicketCheck, Users } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { formatCurrency } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EventCard } from "@/components/events/event-card"

export default async function CreatorDashboardPage() {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in and is a creator
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  if (!profile || profile.user_type !== "creator") {
    redirect("/")
  }

  // Fetch creator's events
  const { data: events } = await supabase
    .from("events")
    .select("*")
    .eq("creator_id", session.user.id)
    .order("created_at", { ascending: false })

  // Fetch ticket sales data
  const { data: ticketSales } = await supabase
    .from("tickets")
    .select(`
      *,
      ticket_types(*)
    `)
    .in("event_id", events?.map((event) => event.id) || [])

  // Calculate total sales and attendees
  const totalSales = ticketSales ? ticketSales.reduce((sum, ticket) => sum + (ticket.ticket_types?.price || 0), 0) : 0

  const totalAttendees = ticketSales ? ticketSales.length : 0

  // Separate events into published and drafts
  const publishedEvents = events?.filter((event) => event.is_published) || []
  const draftEvents = events?.filter((event) => !event.is_published) || []

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
          <h1 className="text-3xl font-bold tracking-tight">Creator Dashboard</h1>
          <Link href="/dashboard/creator/events/new">
            <Button>
              <CalendarPlus className="mr-2 h-4 w-4" />
              Create Event
            </Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Events</CardTitle>
              <CalendarPlus className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{events?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                {publishedEvents.length} published, {draftEvents.length} drafts
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Attendees</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalAttendees}</div>
              <p className="text-xs text-muted-foreground">Across all your events</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
              <TicketCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalSales)}</div>
              <p className="text-xs text-muted-foreground">From ticket purchases</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="published" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="published">Published Events ({publishedEvents.length})</TabsTrigger>
            <TabsTrigger value="drafts">Drafts ({draftEvents.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="published" className="mt-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {publishedEvents.length > 0 ? (
                publishedEvents.map((event) => (
                  <Link key={event.id} href={`/dashboard/creator/events/${event.id}`}>
                    <EventCard event={event} />
                  </Link>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <h3 className="text-xl font-bold">No published events</h3>
                  <p className="text-muted-foreground mt-2">You haven't published any events yet.</p>
                  <Link href="/dashboard/creator/events/new" className="mt-4 inline-block">
                    <Button>Create Event</Button>
                  </Link>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="drafts" className="mt-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {draftEvents.length > 0 ? (
                draftEvents.map((event) => (
                  <Link key={event.id} href={`/dashboard/creator/events/${event.id}`}>
                    <EventCard event={event} />
                  </Link>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <h3 className="text-xl font-bold">No draft events</h3>
                  <p className="text-muted-foreground mt-2">You don't have any events in draft.</p>
                  <Link href="/dashboard/creator/events/new" className="mt-4 inline-block">
                    <Button>Create Event</Button>
                  </Link>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
