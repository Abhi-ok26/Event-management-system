import Link from "next/link"
import { redirect } from "next/navigation"
import { getSupabaseServerClient } from "@/lib/supabase/server"

import { Button } from "@/components/ui/button"
import { TicketCard } from "@/components/tickets/ticket-card"

export default async function AttendeeDashboardPage() {
  const supabase = getSupabaseServerClient()

  // Get current user
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.user_type !== "attendee") {
    redirect("/dashboard")
  }

  // Get user's tickets with event and ticket type information
  const { data: tickets } = await supabase
    .from("tickets")
    .select(
      `
      *,
      events:event_id(*),
      ticket_types:ticket_type_id(*)
    `,
    )
    .eq("attendee_id", user.id)
    .order("purchase_time", { ascending: false })

  const upcomingTickets = tickets?.filter((ticket) => new Date(ticket.events.start_time) > new Date()) || []

  const pastTickets = tickets?.filter((ticket) => new Date(ticket.events.end_time) < new Date()) || []

  const liveTickets =
    tickets?.filter(
      (ticket) => new Date(ticket.events.start_time) <= new Date() && new Date(ticket.events.end_time) >= new Date(),
    ) || []

  return (
    <div className="container py-10">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Tickets</h1>
          <p className="text-muted-foreground">Manage your event tickets and registrations.</p>
        </div>

        {tickets && tickets.length > 0 ? (
          <>
            {liveTickets.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Live Now</h2>
                <div className="grid gap-4 md:grid-cols-2">
                  {liveTickets.map((ticket) => (
                    <TicketCard
                      key={ticket.id}
                      ticket={ticket}
                      event={ticket.events}
                      ticketType={ticket.ticket_types}
                    />
                  ))}
                </div>
              </div>
            )}

            {upcomingTickets.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Upcoming</h2>
                <div className="grid gap-4 md:grid-cols-2">
                  {upcomingTickets.map((ticket) => (
                    <TicketCard
                      key={ticket.id}
                      ticket={ticket}
                      event={ticket.events}
                      ticketType={ticket.ticket_types}
                    />
                  ))}
                </div>
              </div>
            )}

            {pastTickets.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Past Events</h2>
                <div className="grid gap-4 md:grid-cols-2">
                  {pastTickets.map((ticket) => (
                    <TicketCard
                      key={ticket.id}
                      ticket={ticket}
                      event={ticket.events}
                      ticketType={ticket.ticket_types}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-10 text-center">
            <h3 className="text-lg font-semibold">No tickets yet</h3>
            <p className="text-muted-foreground">You haven't purchased any tickets yet.</p>
            <Link href="/events">
              <Button className="mt-4">Browse Events</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
