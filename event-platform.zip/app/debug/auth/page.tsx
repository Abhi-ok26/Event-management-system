"use client"

import { useEffect, useState } from "react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DebugAuthPage() {
  const [sessionData, setSessionData] = useState<any>(null)
  const [profileData, setProfileData] = useState<any>(null)
  const [authConfig, setAuthConfig] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = getSupabaseBrowserClient()

  async function fetchData() {
    setLoading(true)
    setError(null)

    try {
      // Get session
      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession()

      if (sessionError) {
        throw new Error(`Session error: ${sessionError.message}`)
      }

      setSessionData(session)

      // If we have a session, get profile
      if (session) {
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", session.user.id)
          .single()

        if (profileError) {
          throw new Error(`Profile error: ${profileError.message}`)
        }

        setProfileData(profile)
      }

      // Get auth configuration (this is a mock since we can't access Supabase admin settings directly)
      setAuthConfig({
        redirectUrls: [window.location.origin],
        siteUrl: window.location.origin,
        autoConfirmEnabled: false,
        emailConfirmationRequired: true,
        emailSignInEnabled: true,
        passwordSignInEnabled: true,
      })
    } catch (err: any) {
      setError(err.message)
      console.error("Debug error:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  async function testEmailDelivery(email: string) {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/update-password`,
      })

      if (error) throw error

      return { success: true, message: "Test email sent successfully. Please check your inbox and spam folder." }
    } catch (error: any) {
      return { success: false, message: error.message || "Failed to send test email" }
    }
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Auth Debug Page</h1>

      <Tabs defaultValue="status">
        <TabsList>
          <TabsTrigger value="status">Auth Status</TabsTrigger>
          <TabsTrigger value="config">Configuration</TabsTrigger>
          <TabsTrigger value="troubleshoot">Troubleshooting</TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="mt-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Authentication Status</CardTitle>
                <CardDescription>Current session and authentication state</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div>Loading authentication data...</div>
                ) : error ? (
                  <div className="text-red-500">{error}</div>
                ) : (
                  <div>
                    <p className="mb-2">
                      <strong>Authenticated:</strong> {sessionData ? "Yes" : "No"}
                    </p>
                    {sessionData && (
                      <>
                        <p className="mb-2">
                          <strong>User ID:</strong> {sessionData.user.id}
                        </p>
                        <p className="mb-2">
                          <strong>Email:</strong> {sessionData.user.email}
                        </p>
                        <p className="mb-2">
                          <strong>Email Confirmed:</strong> {sessionData.user.email_confirmed_at ? "Yes" : "No"}
                        </p>
                        <p className="mb-2">
                          <strong>Session Expires:</strong> {new Date(sessionData.expires_at * 1000).toLocaleString()}
                        </p>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {profileData && (
              <Card>
                <CardHeader>
                  <CardTitle>User Profile</CardTitle>
                  <CardDescription>Profile data from the database</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-2">
                    <strong>Full Name:</strong> {profileData.full_name || "Not set"}
                  </p>
                  <p className="mb-2">
                    <strong>User Type:</strong> {profileData.user_type}
                  </p>
                  <p className="mb-2">
                    <strong>Created At:</strong> {new Date(profileData.created_at).toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="config" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Auth Configuration</CardTitle>
              <CardDescription>Current authentication settings</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div>Loading configuration data...</div>
              ) : error ? (
                <div className="text-red-500">{error}</div>
              ) : authConfig ? (
                <div className="space-y-2">
                  <p>
                    <strong>Site URL:</strong> {authConfig.siteUrl}
                  </p>
                  <p>
                    <strong>Redirect URLs:</strong>{" "}
                    {authConfig.redirectUrls.map((url: string) => (
                      <span key={url} className="block ml-4">
                        - {url}
                      </span>
                    ))}
                  </p>
                  <p>
                    <strong>Auto Confirm Enabled:</strong> {authConfig.autoConfirmEnabled ? "Yes" : "No"}
                  </p>
                  <p>
                    <strong>Email Confirmation Required:</strong> {authConfig.emailConfirmationRequired ? "Yes" : "No"}
                  </p>
                  <p>
                    <strong>Email Sign In Enabled:</strong> {authConfig.emailSignInEnabled ? "Yes" : "No"}
                  </p>
                  <p>
                    <strong>Password Sign In Enabled:</strong> {authConfig.passwordSignInEnabled ? "Yes" : "No"}
                  </p>
                </div>
              ) : (
                <div>No configuration data available</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="troubleshoot" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Troubleshooting Tools</CardTitle>
              <CardDescription>Tools to help diagnose authentication issues</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Test Email Delivery</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Send a test email to verify email delivery is working correctly
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      placeholder="Enter your email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      id="test-email"
                    />
                    <Button
                      onClick={async () => {
                        const email = (document.getElementById("test-email") as HTMLInputElement).value
                        if (!email) {
                          alert("Please enter an email address")
                          return
                        }

                        const result = await testEmailDelivery(email)
                        alert(result.message)
                      }}
                    >
                      Send Test
                    </Button>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Check Browser Compatibility</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Verify that your browser supports all required features
                  </p>
                  <Button
                    onClick={() => {
                      const features = {
                        localStorage: typeof localStorage !== "undefined",
                        sessionStorage: typeof sessionStorage !== "undefined",
                        cookies: navigator.cookieEnabled,
                        fetch: typeof fetch !== "undefined",
                      }

                      const incompatible = Object.entries(features).filter(([_, supported]) => !supported)

                      if (incompatible.length === 0) {
                        alert("Your browser is compatible with all required features.")
                      } else {
                        alert(
                          `Your browser is missing these required features: ${incompatible.map(([name]) => name).join(", ")}`,
                        )
                      }
                    }}
                  >
                    Check Compatibility
                  </Button>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Clear Local Auth Data</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Clear local authentication data if you're experiencing issues
                  </p>
                  <Button
                    variant="destructive"
                    onClick={async () => {
                      await supabase.auth.signOut({ scope: "local" })
                      localStorage.clear()
                      sessionStorage.clear()
                      alert("Local authentication data cleared. The page will now reload.")
                      window.location.reload()
                    }}
                  >
                    Clear Auth Data
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex gap-4 mt-6">
        <Button onClick={fetchData} disabled={loading}>
          Refresh Data
        </Button>
        <Button
          variant="outline"
          onClick={async () => {
            await supabase.auth.signOut()
            fetchData()
          }}
        >
          Sign Out
        </Button>
      </div>
    </div>
  )
}
