"use server"

import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function updateEmailTemplates() {
  const supabase = getSupabaseServerClient()

  // This is a server-side function that would typically be run once
  // by an admin to update the email templates to support OTP

  // In a real application, you would use the Supabase Admin API
  // to update the email templates, but for this example, we'll
  // just return instructions

  return {
    success: true,
    message: `
      To update your Supabase email templates for OTP:
      
      1. Go to your Supabase dashboard
      2. Navigate to Authentication > Email Templates
      3. Edit the "Magic Link" template
      4. Include the OTP code in the email body using {{ .Token }}
      
      Example template:
      
      <h2>Your verification code</h2>
      <p>Use the following code to verify your account: <strong>{{ .Token }}</strong></p>
      <p>This code will expire in 1 hour.</p>
    `,
  }
}
