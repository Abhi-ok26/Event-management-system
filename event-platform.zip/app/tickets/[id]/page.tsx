import Link from "next/link"
import { redirect } from "next/navigation"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { formatDate, formatTime } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { QRCodeSVG } from "qrcode.react"

export default async function TicketPage({ params }: { params: { id: string } }) {
  const supabase = getSupabaseServerClient()

  // Get user session
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login?redirect=/tickets/" + params.id)
  }

  // Get ticket details with related data
  const { data: ticket, error } = await supabase
    .from("tickets")
    .select(`
      *,
      ticket_types(*),
      events(*)
    `)
    .eq("id", params.id)
    .single()

  if (error || !ticket) {
    console.error("Error fetching ticket:", error)
    redirect("/dashboard/attendee")
  }

  // Check if the ticket belongs to the current user
  if (ticket.attendee_id !== session.user.id) {
    redirect("/dashboard/attendee")
  }

  const event = ticket.events
  const ticketType = ticket.ticket_types

  return (
    <div className="container py-10">
      <div className="max-w-md mx-auto">
        <Card className="border-2">
          <CardHeader className="text-center bg-primary/5 border-b">
            <CardTitle className="text-2xl">Your Ticket</CardTitle>
            <CardDescription>{event.title}</CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="flex justify-center">
              <div className="p-4 bg-white rounded-lg">
                <QRCodeSVG value={ticket.qr_code || params.id} size={200} level="H" includeMargin />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ticket Type</span>
                <span className="font-medium">{ticketType.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date</span>
                <span className="font-medium">{formatDate(event.start_time)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Time</span>
                <span className="font-medium">{formatTime(event.start_time)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Location</span>
                <span className="font-medium">{event.location || "Virtual Event"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ticket ID</span>
                <span className="font-medium">{params.id.substring(0, 8).toUpperCase()}</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-2">
            <Button asChild className="w-full">
              <Link href={`/events/${event.id}`}>View Event Details</Link>
            </Button>
            <Button variant="outline" asChild className="w-full">
              <Link href="/dashboard/attendee">Back to My Tickets</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
