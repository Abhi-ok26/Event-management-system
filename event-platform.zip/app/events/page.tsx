import { getSupabaseServerClient } from "@/lib/supabase/server"
import type { Event } from "@/lib/types"

import { EventCard } from "@/components/events/event-card"
import { EventFilter } from "@/components/events/event-filter"

interface EventsPageProps {
  searchParams: {
    search?: string
    category?: string
    sort?: string
  }
}

export default async function EventsPage({ searchParams }: EventsPageProps) {
  const supabase = getSupabaseServerClient()

  // Get unique categories for filter
  const { data: categoriesData } = await supabase.from("events").select("category").not("category", "is", null)

  const categories = categoriesData ? [...new Set(categoriesData.map((item) => item.category))] : []

  // Build query for events - show all events for testing
  let query = supabase.from("events").select("*")

  // Apply search filter
  if (searchParams.search) {
    query = query.or(`title.ilike.%${searchParams.search}%,description.ilike.%${searchParams.search}%`)
  }

  // Apply category filter
  if (searchParams.category && searchParams.category !== "all") {
    query = query.eq("category", searchParams.category)
  }

  // Apply sorting
  if (searchParams.sort) {
    switch (searchParams.sort) {
      case "date-asc":
        query = query.order("start_time", { ascending: true })
        break
      case "date-desc":
        query = query.order("start_time", { ascending: false })
        break
      default:
        query = query.order("start_time", { ascending: true })
    }
  } else {
    query = query.order("start_time", { ascending: true })
  }

  const { data: events, error } = await query

  // Add debugging to see what's happening
  console.log("Events query error:", error)
  console.log("Events found:", events?.length)

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Discover Events</h1>
          <p className="text-muted-foreground">Browse and book tickets for upcoming events.</p>
        </div>
        {/* Debug information */}
        <div className="mb-4 rounded-md bg-blue-50 p-3 text-sm text-blue-800">
          <p>Found {events?.length || 0} events in the database.</p>
        </div>
        <EventFilter categories={categories} />

        {/* Add debugging information in development */}
        {process.env.NODE_ENV === "development" && (
          <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-md">
            <h3 className="font-semibold">Debug Info:</h3>
            <p>Query error: {error ? JSON.stringify(error) : "None"}</p>
            <p>Events found: {events?.length || 0}</p>
            <p>Note: Showing all events for testing (including unpublished)</p>
          </div>
        )}

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {events && events.length > 0 ? (
            events.map((event: Event) => <EventCard key={event.id} event={event} />)
          ) : (
            <div className="col-span-full text-center py-12">
              <h3 className="text-xl font-bold">No events found</h3>
              <p className="text-muted-foreground mt-2">Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
