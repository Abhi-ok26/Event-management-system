import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { CalendarDays, Clock, MapPin, Users } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { formatCurrency, formatDate, formatTime } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { EventCountdown } from "@/components/events/event-countdown"
import { ShareEvent } from "@/components/events/share-event"
import { SimilarEvents } from "@/components/events/similar-events"
import { EventMap } from "@/components/events/event-map"
import { EventResources } from "@/components/events/event-resources"
import { EventReviews } from "@/components/events/event-reviews"
import { MeetingRoomSection } from "@/components/events/meeting-room-section"

export default async function EventPage({ params }: { params: { id: string } }) {
  const supabase = getSupabaseServerClient()

  // Get current user
  const {
    data: { session },
  } = await supabase.auth.getSession()
  const userId = session?.user.id

  // Get event details
  const { data: event, error } = await supabase.from("events").select("*").eq("id", params.id).single()

  if (error || !event) {
    console.error("Error fetching event:", error)
    notFound()
  }

  // Get creator profile
  const { data: creator } = await supabase.from("profiles").select("*").eq("id", event.creator_id).single()

  // Get ticket types
  const { data: ticketTypes } = await supabase
    .from("ticket_types")
    .select("*")
    .eq("event_id", event.id)
    .order("price", { ascending: true })

  // Check if user has a ticket
  let hasTicket = false
  if (userId) {
    const { data: ticket } = await supabase
      .from("tickets")
      .select("*")
      .eq("event_id", event.id)
      .eq("attendee_id", userId)
      .single()

    hasTicket = !!ticket
  }

  // Check if user is the creator
  const isCreator = userId === event.creator_id

  // If no ticket types exist, create a default one for testing
  if (!ticketTypes || ticketTypes.length === 0) {
    const { error: createError } = await supabase.from("ticket_types").insert({
      event_id: event.id,
      name: "General Admission",
      description: "Standard ticket",
      price: 10.0,
      quantity: 100,
      is_early_bird: false,
      is_vip: false,
    })

    if (createError) {
      console.error("Error creating default ticket type:", createError)
    }
  }

  const isUpcoming = new Date(event.start_time) > new Date()

  return (
    <div className="container py-10">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          <div className="relative">
            <div className="aspect-video relative rounded-lg overflow-hidden">
              {event.thumbnail_url ? (
                <Image
                  src={event.thumbnail_url || "/placeholder.svg"}
                  alt={event.title}
                  fill
                  className="object-cover"
                  priority
                />
              ) : (
                <Image
                  src={`/generic-event-celebration.png`}
                  alt={event.title}
                  fill
                  className="object-cover"
                  priority
                />
              )}
            </div>
            <div className="absolute top-4 right-4">
              <ShareEvent eventId={event.id} eventTitle={event.title} />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              {event.category && (
                <Badge variant="secondary" className="capitalize">
                  {event.category}
                </Badge>
              )}
              <Badge variant="outline" className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                {event.max_attendees || "Unlimited"}
              </Badge>
            </div>
            <h1 className="text-3xl font-bold tracking-tight">{event.title}</h1>
            <div className="flex flex-wrap gap-4 mt-2 text-muted-foreground">
              <div className="flex items-center gap-1">
                <CalendarDays className="h-4 w-4" />
                <span>{formatDate(event.start_time)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>
                  {formatTime(event.start_time)} - {formatTime(event.end_time)}
                </span>
              </div>
              {event.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{event.location}</span>
                </div>
              )}
            </div>
          </div>

          <Tabs defaultValue="about">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="about" className="mt-4">
              <div className="prose max-w-none">
                <p>{event.description}</p>
              </div>
            </TabsContent>
            <TabsContent value="resources" className="mt-4">
              <EventResources eventId={event.id} />
            </TabsContent>
            <TabsContent value="location" className="mt-4">
              <EventMap location={event.location || "Virtual Event"} />
            </TabsContent>
            <TabsContent value="reviews" className="mt-4">
              <EventReviews eventId={event.id} />
            </TabsContent>
          </Tabs>

          <div className="mt-8">
            <h2 className="text-xl font-bold mb-4">Similar Events</h2>
            <SimilarEvents currentEventId={event.id} category={event.category} />
          </div>
        </div>

        <div className="space-y-6">
          {/* Meeting Room Section */}
          <MeetingRoomSection eventId={event.id} hasTicket={hasTicket} isCreator={isCreator} />

          <Card>
            <CardHeader>
              <CardTitle>Event Countdown</CardTitle>
              <CardDescription>Time remaining until the event starts</CardDescription>
            </CardHeader>
            <CardContent>
              <EventCountdown startTime={event.start_time} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tickets</CardTitle>
              <CardDescription>Available ticket options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {ticketTypes && ticketTypes.length > 0 ? (
                ticketTypes.map((ticket) => (
                  <div key={ticket.id} className="rounded-lg border p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium">{ticket.name}</h3>
                        {ticket.description && <p className="text-sm text-muted-foreground">{ticket.description}</p>}
                      </div>
                      <div className="flex gap-2">
                        {ticket.is_early_bird && <Badge variant="secondary">Early Bird</Badge>}
                        {ticket.is_vip && <Badge>VIP</Badge>}
                      </div>
                    </div>
                    <div className="flex justify-between items-center mt-4">
                      <span className="font-bold">{formatCurrency(ticket.price)}</span>
                      <Link href={`/events/${event.id}/tickets/${ticket.id}`}>
                        <Button size="sm">Select</Button>
                      </Link>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No tickets available for this event.</p>
              )}
            </CardContent>
            <CardFooter className="flex justify-center border-t pt-6">
              <Link href={`/events/${event.id}/buy-ticket`}>
                <Button className="w-full">Buy Tickets</Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Organized by</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                  {creator?.avatar_url ? (
                    <Image
                      src={creator.avatar_url || "/placeholder.svg"}
                      alt={creator.full_name || ""}
                      width={40}
                      height={40}
                      className="rounded-full"
                    />
                  ) : (
                    <span className="text-xl font-bold">{(creator?.full_name || "U")[0]}</span>
                  )}
                </div>
                <div>
                  <p className="font-medium">{creator?.full_name || creator?.email || "Unknown Organizer"}</p>
                  <p className="text-sm text-muted-foreground">Event Organizer</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
