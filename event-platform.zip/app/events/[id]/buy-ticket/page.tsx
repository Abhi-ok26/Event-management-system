import { redirect } from "next/navigation"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatCurrency, formatDate, formatTime } from "@/lib/utils"

export default async function BuyTicketPage({ params }: { params: { id: string } }) {
  const supabase = getSupabaseServerClient()

  // Get event details
  const { data: event, error } = await supabase.from("events").select("*").eq("id", params.id).single()

  if (error || !event) {
    console.error("Error fetching event:", error)
    redirect("/events")
  }

  // Get ticket types
  const { data: ticketTypes, error: ticketError } = await supabase
    .from("ticket_types")
    .select("*")
    .eq("event_id", params.id)
    .order("price", { ascending: true })

  if (ticketError) {
    console.error("Error fetching ticket types:", ticketError)
  }

  // Get user session
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Function to handle ticket purchase
  async function purchaseTicket(ticketTypeId: string) {
    "use server"

    const supabase = getSupabaseServerClient()
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session?.user) {
      return redirect("/auth/login?redirect=/events/" + params.id + "/buy-ticket")
    }

    // Get ticket type and event info
    const { data: ticketType } = await supabase
      .from("ticket_types")
      .select("*, events(*)")
      .eq("id", ticketTypeId)
      .single()

    if (!ticketType) {
      return { error: "Ticket type not found" }
    }

    // Generate a unique ticket ID
    const ticketId = crypto.randomUUID()

    // Create the ticket
    const { error: insertError } = await supabase.from("tickets").insert({
      id: ticketId,
      ticket_type_id: ticketTypeId,
      event_id: params.id,
      attendee_id: session.user.id,
      purchase_time: new Date().toISOString(),
      qr_code: `TICKET-${ticketId.substring(0, 8)}`,
      is_used: false,
    })

    if (insertError) {
      console.error("Error creating ticket:", insertError)
      return { error: "Failed to create ticket" }
    }

    // Redirect to the ticket confirmation page
    redirect(`/tickets/${ticketId}`)
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Purchase Tickets</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <Card>
            <CardHeader>
              <CardTitle>{event.title}</CardTitle>
              <CardDescription>
                {formatDate(event.start_time)} • {formatTime(event.start_time)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{event.description}</p>
              <div className="text-sm">
                <strong>Location:</strong> {event.location || "Virtual Event"}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Available Tickets</CardTitle>
              <CardDescription>Select a ticket type to purchase</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {ticketTypes && ticketTypes.length > 0 ? (
                ticketTypes.map((ticket) => (
                  <div key={ticket.id} className="border rounded-lg p-4">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-medium">{ticket.name}</h3>
                        <p className="text-sm text-muted-foreground">{ticket.description}</p>
                      </div>
                      <div className="font-bold">{formatCurrency(ticket.price)}</div>
                    </div>
                    <form action={() => purchaseTicket(ticket.id)} className="mt-4">
                      <Button type="submit" className="w-full">
                        {ticket.price > 0 ? "Buy Now" : "Register Free"}
                      </Button>
                    </form>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No tickets available for this event.</p>
              )}
            </CardContent>
            <CardFooter className="flex flex-col gap-2">
              <p className="text-sm text-muted-foreground">
                By purchasing a ticket, you agree to the terms and conditions.
              </p>
              {!session && (
                <p className="text-sm">
                  <Button variant="link" className="p-0 h-auto" asChild>
                    <a href={`/auth/login?redirect=/events/${params.id}/buy-ticket`}>Sign in</a>
                  </Button>{" "}
                  to purchase tickets
                </p>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
