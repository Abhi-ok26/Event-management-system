"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, MessageSquare, Mic, MicOff, Users, Video, VideoOff } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { joinMeetingRoom, leaveMeetingRoom } from "@/app/actions/meeting-room-actions"
import type { MeetingRoom, Profile } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"

interface MeetingPageProps {
  params: {
    id: string
    meetingId: string
  }
}

export default function MeetingPage({ params }: MeetingPageProps) {
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()
  const [isLoading, setIsLoading] = useState(true)
  const [meetingRoom, setMeetingRoom] = useState<MeetingRoom | null>(null)
  const [participants, setParticipants] = useState<(Profile & { is_presenter: boolean })[]>([])
  const [isPresenter, setIsPresenter] = useState(false)
  const [isMicOn, setIsMicOn] = useState(true)
  const [isVideoOn, setIsVideoOn] = useState(true)

  useEffect(() => {
    async function checkAccess() {
      try {
        setIsLoading(true)

        // Join the meeting room
        const result = await joinMeetingRoom(params.meetingId, params.id)

        if (result.error) {
          toast({
            title: "Access Denied",
            description: result.error,
            variant: "destructive",
          })
          router.push(`/events/${params.id}`)
          return
        }

        setMeetingRoom(result.meetingRoom as MeetingRoom)
        setIsPresenter(result.isPresenter)

        // Load participants
        await loadParticipants()

        // Set up real-time subscription for participants
        const channel = supabase
          .channel("meeting-participants")
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "meeting_participants",
              filter: `meeting_room_id=eq.${params.meetingId}`,
            },
            () => {
              loadParticipants()
            },
          )
          .subscribe()

        return () => {
          channel.unsubscribe()
          // Leave the meeting when component unmounts
          leaveMeetingRoom(params.meetingId)
        }
      } catch (error) {
        console.error("Error checking access:", error)
        toast({
          title: "Error",
          description: "An unexpected error occurred. Please try again.",
          variant: "destructive",
        })
        router.push(`/events/${params.id}`)
      } finally {
        setIsLoading(false)
      }
    }

    async function loadParticipants() {
      const { data } = await supabase
        .from("meeting_participants")
        .select(`
          is_presenter,
          profiles:user_id(*)
        `)
        .eq("meeting_room_id", params.meetingId)
        .is("left_at", null)

      if (data) {
        const formattedParticipants = data.map((p) => ({
          ...(p.profiles as Profile),
          is_presenter: p.is_presenter,
        }))
        setParticipants(formattedParticipants)
      }
    }

    checkAccess()
  }, [params.id, params.meetingId, router, supabase])

  const handleLeaveRoom = async () => {
    await leaveMeetingRoom(params.meetingId)
    router.push(`/events/${params.id}`)
  }

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Joining meeting room...</p>
        </div>
      </div>
    )
  }

  if (!meetingRoom) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <p>Meeting room not found or access denied.</p>
          <Link href={`/events/${params.id}`}>
            <Button className="mt-4">Return to Event</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen">
      <header className="bg-background border-b p-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href={`/events/${params.id}`}>
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-bold">{meetingRoom.name}</h1>
          </div>
          <Button variant="destructive" onClick={handleLeaveRoom}>
            Leave Meeting
          </Button>
        </div>
      </header>

      <main className="flex-1 container grid grid-cols-1 md:grid-cols-4 gap-4 py-6">
        <div className="md:col-span-3 flex flex-col">
          <div className="bg-black rounded-lg aspect-video flex items-center justify-center mb-4">
            {isVideoOn ? (
              <div className="relative w-full h-full">
                {/* This would be replaced with actual video stream */}
                <div className="absolute inset-0 flex items-center justify-center text-white">
                  <p>Video stream would appear here</p>
                </div>
              </div>
            ) : (
              <div className="text-white">
                <VideoOff className="h-16 w-16 mx-auto mb-2" />
                <p>Video is turned off</p>
              </div>
            )}
          </div>

          <div className="flex justify-center space-x-4 p-4 bg-muted rounded-lg">
            <Button
              variant="outline"
              size="icon"
              className={!isMicOn ? "bg-red-100" : ""}
              onClick={() => setIsMicOn(!isMicOn)}
            >
              {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5 text-red-500" />}
            </Button>
            <Button
              variant="outline"
              size="icon"
              className={!isVideoOn ? "bg-red-100" : ""}
              onClick={() => setIsVideoOn(!isVideoOn)}
            >
              {isVideoOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5 text-red-500" />}
            </Button>
          </div>
        </div>

        <div className="md:col-span-1">
          <Tabs defaultValue="participants">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="participants">
                <Users className="h-4 w-4 mr-2" />
                People
              </TabsTrigger>
              <TabsTrigger value="chat">
                <MessageSquare className="h-4 w-4 mr-2" />
                Chat
              </TabsTrigger>
            </TabsList>

            <TabsContent value="participants" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Participants ({participants.length})</h3>
                  <Separator className="my-2" />
                  <div className="space-y-3 max-h-[400px] overflow-y-auto">
                    {participants.map((participant) => (
                      <div key={participant.id} className="flex items-center space-x-3">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          {participant.avatar_url ? (
                            <Image
                              src={participant.avatar_url || "/placeholder.svg"}
                              alt={participant.full_name || ""}
                              width={32}
                              height={32}
                              className="rounded-full"
                            />
                          ) : (
                            <span className="text-sm font-medium">
                              {(participant.full_name || participant.email || "U")[0]}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {participant.full_name || participant.email || "Unknown"}
                            {participant.is_presenter && (
                              <span className="ml-2 text-xs bg-primary/10 text-primary rounded-full px-2 py-0.5">
                                Host
                              </span>
                            )}
                          </p>
                        </div>
                      </div>
                    ))}

                    {participants.length === 0 && <p className="text-sm text-muted-foreground">No participants yet</p>}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Chat</h3>
                  <Separator className="my-2" />
                  <div className="h-[400px] flex items-center justify-center">
                    <p className="text-sm text-muted-foreground">Chat functionality would appear here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
