"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import type { Event, MeetingRoom, Ticket } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { QRCodeDisplay } from "@/components/tickets/qr-code-display"
import { toast } from "@/components/ui/use-toast"

interface JoinEventPageProps {
  params: {
    id: string
  }
}

export default function JoinEventPage({ params }: JoinEventPageProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [event, setEvent] = useState<Event | null>(null)
  const [ticket, setTicket] = useState<Ticket | null>(null)
  const [meetingRoom, setMeetingRoom] = useState<MeetingRoom | null>(null)
  const [hasAccess, setHasAccess] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    async function checkAccess() {
      try {
        setIsLoading(true)

        // Get current user
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          toast({
            title: "Authentication required",
            description: "Please log in to join this event.",
            variant: "destructive",
          })
          router.push("/auth/login")
          return
        }

        // Get event details
        const { data: eventData } = await supabase.from("events").select("*").eq("id", params.id).single()

        if (!eventData) {
          toast({
            title: "Event not found",
            description: "The event you are trying to join does not exist.",
            variant: "destructive",
          })
          router.push("/")
          return
        }

        setEvent(eventData)

        // Check if event is live
        const now = new Date()
        const startTime = new Date(eventData.start_time)
        const endTime = new Date(eventData.end_time)

        if (now < startTime) {
          toast({
            title: "Event has not started yet",
            description: "This event has not started yet. Please come back later.",
            variant: "destructive",
          })
          router.push(`/events/${params.id}`)
          return
        }

        if (now > endTime) {
          toast({
            title: "Event has ended",
            description: "This event has already ended.",
            variant: "destructive",
          })
          router.push(`/events/${params.id}`)
          return
        }

        // Check if user has a ticket
        const { data: ticketData } = await supabase
          .from("tickets")
          .select("*")
          .eq("event_id", params.id)
          .eq("attendee_id", user.id)
          .single()

        if (!ticketData) {
          toast({
            title: "No ticket found",
            description: "You do not have a ticket for this event. Please purchase a ticket to join.",
            variant: "destructive",
          })
          router.push(`/events/${params.id}`)
          return
        }

        setTicket(ticketData)

        // Get meeting room details
        const { data: meetingRoomData } = await supabase
          .from("meeting_rooms")
          .select("*")
          .eq("event_id", params.id)
          .single()

        if (!meetingRoomData) {
          toast({
            title: "Meeting room not set up",
            description: "The meeting room for this event has not been set up yet.",
            variant: "destructive",
          })
          router.push(`/events/${params.id}`)
          return
        }

        setMeetingRoom(meetingRoomData)
        setHasAccess(true)
      } catch (error) {
        console.error("Error checking access:", error)
        toast({
          title: "Error",
          description: "An error occurred while checking your access to this event.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkAccess()
  }, [params.id, router, supabase])

  if (isLoading) {
    return (
      <div className="container flex h-[calc(100vh-200px)] items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p>Checking your access...</p>
        </div>
      </div>
    )
  }

  if (!hasAccess || !event || !ticket || !meetingRoom) {
    return (
      <div className="container flex h-[calc(100vh-200px)] items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p>You do not have access to this event.</p>
          <Button onClick={() => router.push("/")}>Return to Home</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-4xl space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">{event.title}</h1>
          <p className="text-muted-foreground">You are now joining the live event</p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="rounded-xl border overflow-hidden">
              {meetingRoom.room_type === "custom" && meetingRoom.room_url ? (
                <iframe
                  src={meetingRoom.room_url}
                  className="w-full aspect-video"
                  allow="camera; microphone; fullscreen; display-capture; autoplay"
                ></iframe>
              ) : meetingRoom.room_type === "youtube" ? (
                <iframe
                  src={`https://www.youtube.com/embed/${meetingRoom.youtube_stream_key}`}
                  className="w-full aspect-video"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              ) : (
                <div className="flex items-center justify-center bg-muted aspect-video">
                  <p>Meeting room not available</p>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border p-4">
              <h2 className="font-semibold mb-2">Your Ticket</h2>
              <div className="flex justify-center">
                <QRCodeDisplay
                  data={JSON.stringify({
                    ticketId: ticket.id,
                    eventId: event.id,
                    attendeeId: ticket.attendee_id,
                  })}
                  size={150}
                />
              </div>
            </div>

            <div className="rounded-xl border p-4">
              <h2 className="font-semibold mb-2">Event Information</h2>
              <p className="text-sm">{event.description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
