"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { CalendarDays, Check, Clock, Download, MapPin, Share2 } from "lucide-react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { formatDate, formatTime, generateQRCode, generateTicketId } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { QRCodeDisplay } from "@/components/tickets/qr-code-display"
import { toast } from "@/components/ui/use-toast"

export default function ConfirmationPage({
  params,
  searchParams,
}: {
  params: { id: string; ticketTypeId: string }
  searchParams: { name: string; email: string }
}) {
  const [isLoading, setIsLoading] = useState(true)
  const [event, setEvent] = useState<any>(null)
  const [ticketType, setTicketType] = useState<any>(null)
  const [ticketId, setTicketId] = useState<string>("")
  const [qrData, setQrData] = useState<string>("")
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  useEffect(() => {
    async function fetchData() {
      try {
        // Get current user
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          toast({
            title: "Authentication required",
            description: "Please log in to view your ticket.",
            variant: "destructive",
          })
          router.push("/auth/login")
          return
        }

        // Get event and ticket type details
        const { data: eventData } = await supabase.from("events").select("*").eq("id", params.id).single()

        const { data: ticketTypeData } = await supabase
          .from("ticket_types")
          .select("*")
          .eq("id", params.ticketTypeId)
          .single()

        if (!eventData || !ticketTypeData) {
          throw new Error("Event or ticket type not found")
        }

        setEvent(eventData)
        setTicketType(ticketTypeData)

        // Generate ticket data
        const newTicketId = generateTicketId()
        setTicketId(newTicketId)

        const ticketData = JSON.stringify({
          ticketId: newTicketId,
          eventId: eventData.id,
          attendeeId: user.id,
          attendeeName: searchParams.name,
          attendeeEmail: searchParams.email,
          timestamp: new Date().toISOString(),
        })

        setQrData(ticketData)

        // Create ticket in database
        const qrCode = await generateQRCode(ticketData)

        const { error } = await supabase.from("tickets").insert({
          id: newTicketId,
          ticket_type_id: ticketTypeData.id,
          event_id: eventData.id,
          attendee_id: user.id,
          purchase_time: new Date().toISOString(),
          qr_code: qrCode,
          is_used: false,
        })

        if (error) {
          console.error("Error creating ticket:", error)
          // Continue anyway for demo purposes
        }
      } catch (error: any) {
        console.error("Error:", error)
        toast({
          title: "Error retrieving ticket information",
          description: error.message || "Something went wrong. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [params.id, params.ticketTypeId, searchParams.name, searchParams.email, router, supabase])

  if (isLoading) {
    return (
      <div className="container py-10">
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  if (!event || !ticketType) {
    return (
      <div className="container py-10">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Error</h1>
          <p className="text-muted-foreground">Could not retrieve ticket information.</p>
          <Button className="mt-4" onClick={() => router.push("/events")}>
            Browse Events
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-md space-y-6">
        <div className="space-y-2 text-center">
          <div className="inline-flex items-center justify-center rounded-full bg-green-100 p-2">
            <Check className="h-6 w-6 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold">Ticket Confirmed!</h1>
          <p className="text-muted-foreground">Your ticket has been successfully purchased.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Ticket Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <QRCodeDisplay data={qrData} size={200} />
            </div>

            <div className="text-center">
              <h2 className="text-xl font-bold">{event.title}</h2>
              <p className="text-sm text-muted-foreground">{ticketType.name}</p>
              <p className="text-xs font-mono mt-1">Ticket ID: {ticketId}</p>
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex items-center text-sm">
                <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>{formatDate(event.start_time)}</span>
              </div>
              <div className="flex items-center text-sm">
                <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>
                  {formatTime(event.start_time)} - {formatTime(event.end_time)}
                </span>
              </div>
              <div className="flex items-center text-sm">
                <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>{event.location || "Virtual Event"}</span>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <p className="text-sm font-medium">Attendee Information</p>
              <p className="text-sm">{searchParams.name}</p>
              <p className="text-sm text-muted-foreground">{searchParams.email}</p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" size="sm" className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Save Ticket
            </Button>
            <Button variant="outline" size="sm" className="flex items-center">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </CardFooter>
        </Card>

        <div className="flex justify-between">
          <Link href={`/events/${event.id}`}>
            <Button variant="ghost">Back to Event</Button>
          </Link>
          <Link href="/dashboard/attendee">
            <Button>View My Tickets</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
