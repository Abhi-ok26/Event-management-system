"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { CreditCard, Lock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/components/ui/use-toast"

const paymentSchema = z.object({
  cardNumber: z.string().regex(/^\d{16}$/, {
    message: "Card number must be 16 digits",
  }),
  cardName: z.string().min(2, {
    message: "Name must be at least 2 characters",
  }),
  expiryDate: z.string().regex(/^(0[1-9]|1[0-2])\/\d{2}$/, {
    message: "Expiry date must be in MM/YY format",
  }),
  cvv: z.string().regex(/^\d{3,4}$/, {
    message: "CVV must be 3 or 4 digits",
  }),
  paymentMethod: z.enum(["credit", "debit"]),
})

type PaymentFormValues = z.infer<typeof paymentSchema>

export default function PaymentPage({
  params,
  searchParams,
}: {
  params: { id: string; ticketTypeId: string }
  searchParams: { name: string; email: string }
}) {
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      cardNumber: "",
      cardName: "",
      expiryDate: "",
      cvv: "",
      paymentMethod: "credit",
    },
  })

  async function onSubmit(data: PaymentFormValues) {
    setIsProcessing(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    try {
      // In a real app, we would process the payment here
      // For this mock implementation, we'll just redirect to the confirmation page

      toast({
        title: "Payment successful",
        description: "Your payment has been processed successfully.",
      })

      // Redirect to confirmation page with the form data
      router.push(
        `/events/${params.id}/tickets/${params.ticketTypeId}/confirmation?name=${encodeURIComponent(
          searchParams.name,
        )}&email=${encodeURIComponent(searchParams.email)}`,
      )
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-md space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-3xl font-bold">Payment Details</h1>
          <p className="text-muted-foreground">Please enter your payment information to complete your purchase.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="mr-2 h-5 w-5" />
              Payment Information
            </CardTitle>
            <CardDescription>All transactions are secure and encrypted.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel>Payment Method</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex space-x-4"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="credit" id="credit" />
                            <label
                              htmlFor="credit"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Credit Card
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="debit" id="debit" />
                            <label
                              htmlFor="debit"
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Debit Card
                            </label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="cardNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Card Number</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="1234 5678 9012 3456"
                          {...field}
                          onChange={(e) => {
                            // Only allow digits and format with spaces
                            const value = e.target.value.replace(/\D/g, "").substring(0, 16)
                            field.onChange(value)
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="cardName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name on Card</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="expiryDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expiry Date</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="MM/YY"
                            {...field}
                            onChange={(e) => {
                              let value = e.target.value.replace(/\D/g, "")
                              if (value.length > 0) {
                                value = value.match(/.{1,2}/g)?.join("/") || ""
                                if (value.length > 5) value = value.substring(0, 5)
                              }
                              field.onChange(value)
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="cvv"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CVV</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="123"
                            {...field}
                            onChange={(e) => {
                              const value = e.target.value.replace(/\D/g, "").substring(0, 4)
                              field.onChange(value)
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Lock className="h-4 w-4" />
                  <span>Your payment information is secure and encrypted</span>
                </div>

                <Button type="submit" className="w-full" disabled={isProcessing}>
                  {isProcessing ? "Processing..." : "Pay Now"}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-between border-t px-6 py-4">
            <Button variant="ghost" onClick={() => router.back()}>
              Back
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                // Skip payment for testing
                router.push(
                  `/events/${params.id}/tickets/${params.ticketTypeId}/confirmation?name=${encodeURIComponent(
                    searchParams.name,
                  )}&email=${encodeURIComponent(searchParams.email)}`,
                )
              }}
            >
              Skip (Demo)
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
