"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { formatCurrency } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"

const ticketPurchaseSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
})

type TicketPurchaseValues = z.infer<typeof ticketPurchaseSchema>

export default function TicketPurchasePage({
  params,
}: {
  params: { id: string; ticketTypeId: string }
}) {
  const [isLoading, setIsLoading] = useState(true)
  const [event, setEvent] = useState<any>(null)
  const [ticketType, setTicketType] = useState<any>(null)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  useState(() => {
    async function fetchData() {
      try {
        // Get event and ticket type details
        const { data: eventData } = await supabase.from("events").select("*").eq("id", params.id).single()

        const { data: ticketTypeData } = await supabase
          .from("ticket_types")
          .select("*")
          .eq("id", params.ticketTypeId)
          .single()

        if (!eventData || !ticketTypeData) {
          throw new Error("Event or ticket type not found")
        }

        setEvent(eventData)
        setTicketType(ticketTypeData)
      } catch (error: any) {
        toast({
          title: "Error retrieving event information",
          description: error.message || "Something went wrong. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [params.id, params.ticketTypeId, supabase])

  const form = useForm<TicketPurchaseValues>({
    resolver: zodResolver(ticketPurchaseSchema),
    defaultValues: {
      name: "",
      email: "",
    },
  })

  async function onSubmit(data: TicketPurchaseValues) {
    try {
      // Get current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please log in to purchase tickets.",
          variant: "destructive",
        })
        router.push("/auth/login")
        return
      }

      // Redirect to payment page
      router.push(
        `/events/${params.id}/tickets/${params.ticketTypeId}/payment?name=${encodeURIComponent(
          data.name,
        )}&email=${encodeURIComponent(data.email)}`,
      )
    } catch (error: any) {
      toast({
        title: "Error processing request",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="container py-10">
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  if (!event || !ticketType) {
    return (
      <div className="container py-10">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Error</h1>
          <p className="text-muted-foreground">Could not retrieve event information.</p>
          <Button className="mt-4" onClick={() => router.push("/events")}>
            Browse Events
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-md space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-3xl font-bold">Purchase Ticket</h1>
          <p className="text-muted-foreground">
            {ticketType.name} - {formatCurrency(ticketType.price)}
          </p>
          <p className="text-sm font-medium">{event.title}</p>
        </div>
        <div className="rounded-xl border bg-card p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormDescription>This name will be displayed on your ticket.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="john@example.com" {...field} />
                    </FormControl>
                    <FormDescription>We'll send event updates to this email.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full">
                Continue to Payment
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  )
}
