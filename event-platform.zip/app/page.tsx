import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Calendar, CheckCircle, Users } from "lucide-react"
import { getSupabaseServerClient } from "@/lib/supabase/server"
import type { Event } from "@/lib/types"

import { Button } from "@/components/ui/button"
import { EventCard } from "@/components/events/event-card"
import { Suspense } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export default function HomePage() {
  return (
    <div className="container mx-auto py-10">
      <Suspense fallback={<div>Loading...</div>}>
        <HomeContent />
      </Suspense>
    </div>
  )
}

async function HomeContent() {
  const supabase = getSupabaseServerClient()

  // Check if user is logged in
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Fetch upcoming events
  const { data: upcomingEvents } = await supabase
    .from("events")
    .select("*")
    .eq("is_published", true)
    .gte("start_time", new Date().toISOString())
    .order("start_time", { ascending: true })
    .limit(3)

  return (
    <div className="flex flex-col">
      {/* Auth Debug Banner */}
      {!session && (
        <Alert className="mb-6">
          <InfoIcon className="h-4 w-4" />
          <AlertTitle>Quick Access</AlertTitle>
          <AlertDescription>
            Having trouble with signup? Try our{" "}
            <Link href="/auth/direct-signup" className="font-medium underline">
              direct signup
            </Link>{" "}
            method with no verification required.
          </AlertDescription>
        </Alert>
      )}

      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Virtual Events Made Simple
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Book, host, and attend virtual events all in one place. No external tools needed.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/events">
                  <Button size="lg">
                    Discover Events
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href={session ? "/dashboard/attendee" : "/auth/direct-signup"}>
                  <Button variant="outline" size="lg">
                    {session ? "My Dashboard" : "Create an Account"}
                  </Button>
                </Link>
              </div>
            </div>
            <div className="mx-auto w-full max-w-[500px] lg:max-w-none">
              <Image
                src="/virtual-event-conference.png"
                alt="Virtual Event"
                width={600}
                height={400}
                className="w-full rounded-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Everything You Need for Virtual Events
              </h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our platform provides all the tools you need to create, manage, and attend virtual events.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12 mt-12">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Easy Booking</h3>
                <p className="text-muted-foreground">Book tickets for live virtual events with just a few clicks.</p>
              </div>
            </div>
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Integrated Hosting</h3>
                <p className="text-muted-foreground">Host events directly on our platform with no external tools.</p>
              </div>
            </div>
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">Secure Tickets</h3>
                <p className="text-muted-foreground">QR codes tied to your identity for secure event access.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Upcoming Events</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Discover and book tickets for these upcoming virtual events.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12 mt-12">
            {upcomingEvents && upcomingEvents.length > 0 ? (
              upcomingEvents.map((event: Event) => <EventCard key={event.id} event={event} />)
            ) : (
              <div className="col-span-3 text-center py-12">
                <h3 className="text-xl font-bold">No upcoming events</h3>
                <p className="text-muted-foreground mt-2">Check back soon for new events or create your own!</p>
              </div>
            )}
          </div>
          <div className="flex justify-center mt-8">
            <Link href="/events">
              <Button size="lg">
                View All Events
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
