import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const { eventId } = await request.json()

    if (!eventId) {
      return NextResponse.json({ error: "Event ID is required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Get the current user session
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if the user is the creator of the event
    const { data: event, error: eventError } = await supabase
      .from("events")
      .select("*")
      .eq("id", eventId)
      .eq("creator_id", session.user.id)
      .single()

    if (eventError || !event) {
      return NextResponse.json({ error: "Event not found or you don't have permission to publish it" }, { status: 404 })
    }

    // Update the event to published
    const { error: updateError } = await supabase
      .from("events")
      .update({
        is_published: true,
        updated_at: new Date().toISOString(),
      })
      .eq("id", eventId)

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Event published successfully" })
  } catch (error: any) {
    console.error("Error publishing event:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
