import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = getSupabaseServerClient()

    // Test database connection
    const { data: dbData, error: dbError } = await supabase.from("profiles").select("count").limit(1)

    // Test auth system
    const { data: authData, error: authError } = await supabase.auth.getSession()

    // Test environment variables
    const envCheck = {
      supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ? "Defined" : "Missing",
      supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "Defined" : "Missing",
      supabaseServiceRole: process.env.SUPABASE_SERVICE_ROLE_KEY ? "Defined" : "Missing",
      nodeEnv: process.env.NODE_ENV,
    }

    return NextResponse.json({
      success: true,
      database: {
        success: !dbError,
        error: dbError ? dbError.message : null,
        data: dbData,
      },
      auth: {
        success: !authError,
        error: authError ? authError.message : null,
        session: authData.session ? "Present" : "None",
      },
      environment: envCheck,
    })
  } catch (error: any) {
    console.error("Server test connection error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Unknown server error",
      },
      { status: 500 },
    )
  }
}
