import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    message: "Instructions to disable email verification in Supabase",
    steps: [
      "1. Go to your Supabase dashboard",
      "2. Navigate to Authentication > Providers",
      "3. Click on 'Email'",
      "4. Uncheck 'Confirm email'",
      "5. Save changes",
      "Note: This can only be done from the Supabase dashboard by a project admin",
    ],
  })
}
