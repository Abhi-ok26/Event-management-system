import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const { userId, email, fullName, userType } = await request.json()

    if (!userId || !email) {
      return NextResponse.json({ error: "User ID and email are required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Skip the email confirmation step that was causing the error
    // We'll rely on Supabase's built-in confirmation process instead

    // Check if profile already exists
    const { data: existingProfile } = await supabase.from("profiles").select("*").eq("id", userId).single()

    if (existingProfile) {
      // Profile already exists, update it
      const { error: updateProfileError } = await supabase
        .from("profiles")
        .update({
          full_name: fullName,
          user_type: userType,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateProfileError) {
        console.error("Error updating profile:", updateProfileError)
        return NextResponse.json({ error: updateProfileError.message }, { status: 500 })
      }

      return NextResponse.json({ success: true, profile: existingProfile, updated: true })
    }

    // Create profile if it doesn't exist
    const { data: newProfile, error: insertError } = await supabase
      .from("profiles")
      .insert({
        id: userId,
        email,
        full_name: fullName,
        user_type: userType,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (insertError) {
      console.error("Error creating profile:", insertError)
      return NextResponse.json({ error: insertError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, profile: newProfile, created: true })
  } catch (error: any) {
    console.error("Server error in create-profile:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
