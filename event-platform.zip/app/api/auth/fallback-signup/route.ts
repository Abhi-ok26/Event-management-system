import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/lib/database.types"

// Create a Supabase client with the anon key for standard operations
const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    const { email, password, fullName, userType } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    console.log("Starting fallback signup process for:", email)

    // Step 1: Create the user with standard signup
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          user_type: userType,
        },
      },
    })

    if (authError || !authData.user) {
      console.error("Error in fallback signup:", authError)
      return NextResponse.json({ error: authError?.message || "Failed to create user" }, { status: 500 })
    }

    const userId = authData.user.id

    // Step 2: Try to create the profile
    // This might fail due to RLS, but we'll try anyway
    const { error: profileError } = await supabase.from("profiles").insert({
      id: userId,
      email,
      full_name: fullName,
      user_type: userType,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    // Even if profile creation fails, we return success since the user was created
    // The profile will be created by the trigger or when the user logs in
    if (profileError) {
      console.log("Profile creation in fallback failed (expected):", profileError.message)
    }

    return NextResponse.json({
      success: true,
      userId,
      message: "Account created with fallback method. Please check your email for verification.",
      requiresVerification: true,
    })
  } catch (error: any) {
    console.error("Server error in fallback-signup:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
