import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Create a Supabase client with the service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET() {
  try {
    // Create a function to handle user creation
    const createProfileFunctionSQL = `
      CREATE OR REPLACE FUNCTION public.handle_new_user()
      RETURNS TRIGGER AS $$
      BEGIN
        INSERT INTO public.profiles (id, email, full_name, user_type, created_at, updated_at)
        VALUES (
          NEW.id,
          NEW.email,
          COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
          COALESCE(NEW.raw_user_meta_data->>'user_type', 'attendee'),
          NOW(),
          NOW()
        )
        ON CONFLICT (id) DO NOTHING;
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql SECURITY DEFINER;
    `

    // Create a trigger to call the function when a user is created
    const createTriggerSQL = `
      DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
      CREATE TRIGGER on_auth_user_created
        AFTER INSERT ON auth.users
        FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
    `

    // Execute the SQL
    const { error: functionError } = await supabaseAdmin.rpc("pgfunction", { query: createProfileFunctionSQL })
    if (functionError) {
      return NextResponse.json({ error: functionError.message }, { status: 500 })
    }

    const { error: triggerError } = await supabaseAdmin.rpc("pgfunction", { query: createTriggerSQL })
    if (triggerError) {
      return NextResponse.json({ error: triggerError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Database triggers set up successfully" })
  } catch (error: any) {
    console.error("Error setting up triggers:", error)
    return NextResponse.json({ error: error.message || "Unknown error" }, { status: 500 })
  }
}
