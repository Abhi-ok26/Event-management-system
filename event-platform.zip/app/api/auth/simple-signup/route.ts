import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const { email, password, fullName, userType } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Use standard signUp instead of admin.createUser
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName || email.split("@")[0],
          user_type: userType || "attendee",
        },
      },
    })

    if (error) {
      console.error("Error creating user:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!data.user) {
      return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
    }

    // Don't try to create the profile here - we'll do that from the client side
    // after the user is authenticated to avoid RLS policy issues

    // Return success with user data
    return NextResponse.json({
      success: true,
      user: data.user,
      session: data.session,
      message: data.session
        ? "Account created and logged in successfully"
        : "Account created. Please check your email for verification instructions.",
    })
  } catch (error: any) {
    console.error("Server error in simple-signup:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
