import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function POST(request: Request) {
  try {
    const { email, password, fullName, userType } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Step 1: Check if user already exists
    const { data: existingUser } = await supabase.auth.admin.getUserByEmail(email)

    if (existingUser?.user) {
      return NextResponse.json(
        { error: "A user with this email already exists. Please try logging in instead." },
        { status: 400 },
      )
    }

    // Step 2: Create user with auto-confirmation
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName || email.split("@")[0],
        user_type: userType || "attendee",
      },
    })

    if (error) {
      console.error("Error creating user:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!data.user) {
      return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
    }

    // Step 3: Create profile
    const { error: profileError } = await supabase.from("profiles").insert({
      id: data.user.id,
      email: data.user.email!,
      full_name: fullName || data.user.email!.split("@")[0],
      user_type: userType || "attendee",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (profileError) {
      console.error("Error creating profile:", profileError)
      // Continue anyway, as we've already created the user
    }

    // Step 4: Create a session for the user
    const { data: sessionData, error: sessionError } = await supabase.auth.admin.createSession({
      user_id: data.user.id,
    })

    if (sessionError) {
      console.error("Error creating session:", sessionError)
      return NextResponse.json({
        success: true,
        user: data.user,
        warning: "User created but automatic login failed. Please log in manually.",
      })
    }

    // Return the session data so the client can set cookies
    return NextResponse.json({
      success: true,
      user: data.user,
      session: sessionData,
    })
  } catch (error: any) {
    console.error("Server error in direct-signup:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
