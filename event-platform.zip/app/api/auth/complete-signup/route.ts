import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/lib/database.types"

// Create a Supabase client with the service role key for admin operations
const supabaseAdmin = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    const { email, password, fullName, userType } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    console.log("Starting complete signup process for:", email)

    // Step 1: Try to create the user directly
    // If the user already exists, we'll get an error
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Skip email verification
      user_metadata: {
        full_name: fullName,
        user_type: userType,
      },
    })

    // If we get a "User already registered" error, we'll try to update the user
    let userId: string

    if (createError && createError.message.includes("already registered")) {
      console.log("User already exists, trying to find and update")

      // Try to find the user by email using a query
      const { data: users, error: listError } = await supabaseAdmin.auth.admin.listUsers()

      if (listError) {
        console.error("Error listing users:", listError)
        return NextResponse.json({ error: "Failed to check existing users" }, { status: 500 })
      }

      const existingUser = users.users.find((user) => user.email === email)

      if (!existingUser) {
        console.error("User exists but couldn't be found in the list")
        return NextResponse.json({ error: "User exists but couldn't be found" }, { status: 500 })
      }

      userId = existingUser.id

      // Update user metadata
      const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        user_metadata: {
          full_name: fullName,
          user_type: userType,
        },
      })

      if (updateError) {
        console.error("Error updating user:", updateError)
        return NextResponse.json({ error: "Failed to update existing user" }, { status: 500 })
      }
    } else if (createError) {
      // If there's any other error during user creation
      console.error("Error creating user:", createError)
      return NextResponse.json({ error: createError.message || "Failed to create user" }, { status: 500 })
    } else {
      // If user was created successfully
      userId = newUser!.user.id
    }

    // Step 2: Create or update profile
    const { error: profileError } = await supabaseAdmin.from("profiles").upsert(
      {
        id: userId,
        email,
        full_name: fullName,
        user_type: userType,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" },
    )

    if (profileError) {
      console.error("Error creating profile:", profileError)
      return NextResponse.json(
        {
          error: "User created but profile creation failed",
          details: profileError.message,
          userId,
        },
        { status: 500 },
      )
    }

    // Step 3: Generate a sign-in link for the user
    const { data: signInData, error: signInError } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email,
      options: {
        redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/callback`,
      },
    })

    if (signInError) {
      console.error("Error generating sign-in link:", signInError)
      return NextResponse.json({
        warning: "Account created but couldn't generate automatic login. Please log in manually.",
        userId,
      })
    }

    return NextResponse.json({
      success: true,
      userId,
      hintToken: signInData.properties.hashed_token,
      message: "Account created successfully",
    })
  } catch (error: any) {
    console.error("Server error in complete-signup:", error)
    return NextResponse.json({ error: error.message || "Server error" }, { status: 500 })
  }
}
