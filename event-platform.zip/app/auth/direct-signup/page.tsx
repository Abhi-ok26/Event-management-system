"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

const signupSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  userType: z.enum(["attendee", "creator"], {
    required_error: "Please select a user type",
  }),
})

type SignupValues = z.infer<typeof signupSchema>

export default function DirectSignupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [debugInfo, setDebugInfo] = useState<any>(null)
  const [showDebug, setShowDebug] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseBrowserClient()

  const form = useForm<SignupValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      email: "",
      password: "",
      fullName: "",
      userType: "attendee",
    },
  })

  async function onSubmit(data: SignupValues) {
    setIsLoading(true)
    setError(null)
    setDebugInfo(null)

    try {
      // Try the bypass route first (development only)
      try {
        const bypassResponse = await fetch("/api/auth/bypass", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        })

        if (bypassResponse.ok) {
          // Bypass worked, redirect to it
          window.location.href = `/auth/bypass?email=${encodeURIComponent(data.email)}&password=${encodeURIComponent(
            data.password,
          )}&fullName=${encodeURIComponent(data.fullName)}&userType=${data.userType}&redirectTo=/`
          return
        }
      } catch (bypassError) {
        console.log("Bypass not available, continuing with standard signup")
      }

      // Standard signup flow
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            full_name: data.fullName,
            user_type: data.userType,
          },
        },
      })

      if (signUpError) {
        console.error("Signup error:", signUpError)
        setDebugInfo({ type: "signup_error", error: signUpError })
        throw signUpError
      }

      if (!authData.user) {
        const noUserError = new Error("User account could not be created")
        setDebugInfo({ type: "no_user_error", authData })
        throw noUserError
      }

      setDebugInfo({ type: "signup_success", user: authData.user, session: authData.session })

      // If we have a session, create the profile
      if (authData.session) {
        try {
          // Create the profile as the authenticated user
          const { error: profileError } = await supabase.from("profiles").insert({
            id: authData.user.id,
            email: data.email,
            full_name: data.fullName,
            user_type: data.userType,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })

          if (profileError) {
            console.warn("Profile creation error:", profileError)
            setDebugInfo((prev: any) => ({ ...prev, profileError }))
            // Continue anyway - the profile might be created by a database trigger
          } else {
            setDebugInfo((prev: any) => ({ ...prev, profileCreated: true }))
          }
        } catch (profileError: any) {
          console.error("Profile creation error:", profileError)
          setDebugInfo((prev: any) => ({ ...prev, profileError }))
          // Continue anyway since the user account was created
        }

        toast({
          title: "Account created successfully",
          description: "You have been signed in automatically.",
        })

        router.push("/")
        router.refresh()
      } else {
        // No session means email verification is required
        // Try to sign in directly as a fallback
        try {
          const { error: signInError } = await supabase.auth.signInWithPassword({
            email: data.email,
            password: data.password,
          })

          if (signInError) {
            console.warn("Auto-login failed:", signInError)
            setDebugInfo((prev: any) => ({ ...prev, signInError }))
            toast({
              title: "Account created",
              description: "Your account was created but you need to verify your email before logging in.",
            })
            return
          }

          // If sign-in worked, create the profile
          try {
            const { error: profileError } = await supabase.from("profiles").insert({
              id: authData.user.id,
              email: data.email,
              full_name: data.fullName,
              user_type: data.userType,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })

            if (profileError) {
              console.warn("Profile creation error after sign-in:", profileError)
              setDebugInfo((prev: any) => ({ ...prev, profileErrorAfterSignIn: profileError }))
            }
          } catch (profileError: any) {
            console.error("Profile creation error after sign-in:", profileError)
            setDebugInfo((prev: any) => ({ ...prev, profileErrorAfterSignIn: profileError }))
          }

          toast({
            title: "Account created successfully",
            description: "You have been signed in automatically.",
          })

          router.push("/")
          router.refresh()
        } catch (signInError: any) {
          console.error("Sign-in error after signup:", signInError)
          setDebugInfo((prev: any) => ({ ...prev, signInError }))

          toast({
            title: "Account created",
            description: "Your account was created but you need to verify your email before logging in.",
          })
        }
      }
    } catch (error: any) {
      console.error("Signup error:", error)
      setError(error.message || "An error occurred during signup")

      toast({
        title: "Signup failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Direct Signup</CardTitle>
          <CardDescription>Create an account with no verification required</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="userType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Account Type</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="attendee" />
                          </FormControl>
                          <FormLabel className="font-normal">Attendee - I want to discover and attend events</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="creator" />
                          </FormControl>
                          <FormLabel className="font-normal">Creator - I want to host and manage events</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Creating account..." : "Create account & login"}
              </Button>
            </form>
          </Form>

          <div className="text-center mt-4">
            <Button variant="link" size="sm" onClick={() => setShowDebug(!showDebug)}>
              {showDebug ? "Hide Debug Info" : "Show Debug Info"}
            </Button>
          </div>

          {showDebug && debugInfo && (
            <Alert className="mt-4">
              <InfoIcon className="h-4 w-4" />
              <AlertTitle>Debug Information</AlertTitle>
              <AlertDescription className="overflow-auto max-h-40 text-xs">
                <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => router.push("/auth/login")}>
            Return to login
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
