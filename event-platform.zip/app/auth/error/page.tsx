"use client"

import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function AuthErrorPage() {
  const searchParams = useSearchParams()

  const error = searchParams.get("error")
  const errorCode = searchParams.get("error_code")
  const errorDescription = searchParams.get("error_description")

  // Format the error description by replacing + with spaces and decoding URI components
  const formattedErrorDescription = errorDescription
    ? decodeURIComponent(errorDescription.replace(/\+/g, " "))
    : "An unknown error occurred during authentication"

  return (
    <div className="container flex items-center justify-center min-h-[80vh] py-10">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Authentication Error</CardTitle>
          <CardDescription>There was a problem with your authentication</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="font-medium text-red-800">Error: {errorCode || error}</p>
            <p className="text-red-700 mt-1">{formattedErrorDescription}</p>
          </div>

          <div className="space-y-2">
            <p className="text-sm">What would you like to do?</p>

            <div className="flex flex-col space-y-2">
              {errorCode === "otp_expired" && (
                <Link href={`/auth/verify`} passHref>
                  <Button className="w-full">Verify with OTP Code</Button>
                </Link>
              )}

              <Link href="/auth/login" passHref>
                <Button variant="outline" className="w-full">
                  Return to Login
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-muted-foreground">Need help? Contact our support team.</p>
        </CardFooter>
      </Card>
    </div>
  )
}
