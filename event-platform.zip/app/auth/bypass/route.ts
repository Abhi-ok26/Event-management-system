import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function GET(request: Request) {
  // This should only be used in development
  if (process.env.NODE_ENV !== "development") {
    return NextResponse.json({ error: "This endpoint is only available in development mode" }, { status: 403 })
  }

  const url = new URL(request.url)
  const email = url.searchParams.get("email")
  const password = url.searchParams.get("password") || "password123"
  const userType = (url.searchParams.get("userType") as "attendee" | "creator") || "attendee"
  const fullName = url.searchParams.get("fullName") || "Test User"

  if (!email) {
    return NextResponse.json({ error: "Email parameter is required" }, { status: 400 })
  }

  try {
    const supabase = getSupabaseServerClient()

    // Check if user exists
    const { data: existingUser } = await supabase.auth.admin.getUserByEmail(email)

    if (!existingUser?.user) {
      // Create user if they don't exist
      await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: {
          full_name: fullName,
          user_type: userType,
        },
      })
    }

    // Sign in the user
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      throw error
    }

    // Ensure profile exists
    const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

    if (!profile) {
      await supabase.from("profiles").insert({
        id: data.user.id,
        email,
        full_name: fullName,
        user_type: userType,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
    }

    // Redirect to home page
    const redirectUrl = url.searchParams.get("redirectTo") || "/"
    return NextResponse.redirect(new URL(redirectUrl, request.url))
  } catch (error: any) {
    console.error("Auth bypass error:", error)
    return NextResponse.json({ error: error.message || "Authentication failed" }, { status: 500 })
  }
}
