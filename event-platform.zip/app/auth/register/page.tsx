import { CompleteAuthForm } from "@/components/auth/complete-auth-form"

export default function RegisterPage() {
  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <CompleteAuthForm />
    </div>
  )
}
