"use client"

import { useState } from "react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function TestAuthPage() {
  const [email, setEmail] = useState("test@example.com")
  const [password, setPassword] = useState("password123")
  const [fullName, setFullName] = useState("Test User")
  const [userType, setUserType] = useState("attendee")
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = getSupabaseBrowserClient()

  async function testSignUp() {
    setIsLoading(true)
    setError(null)
    try {
      console.log("Testing signup with:", { email, password, fullName, userType })

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            user_type: userType,
          },
        },
      })

      if (error) throw error

      setResult(data)

      if (data.user) {
        // Try to create profile
        const { error: profileError } = await supabase.from("profiles").insert({
          id: data.user.id,
          email: email,
          full_name: fullName,
          user_type: userType,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (profileError) {
          console.error("Profile creation error:", profileError)
          setError(`User created but profile creation failed: ${profileError.message}`)
        } else {
          setResult({ ...data, profileCreated: true })
        }
      }
    } catch (err: any) {
      console.error("Test error:", err)
      setError(err.message || "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  async function testSignIn() {
    setIsLoading(true)
    setError(null)
    try {
      console.log("Testing signin with:", { email, password })

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      setResult(data)
    } catch (err: any) {
      console.error("Test error:", err)
      setError(err.message || "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Auth Test Page</CardTitle>
          <CardDescription>Test authentication directly with Supabase</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium">Email</label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@example.com" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Password</label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Full Name</label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="John Doe" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">User Type</label>
            <select
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2"
              value={userType}
              onChange={(e) => setUserType(e.target.value)}
            >
              <option value="attendee">Attendee</option>
              <option value="creator">Creator</option>
            </select>
          </div>

          <div className="flex space-x-2 pt-4">
            <Button onClick={testSignUp} disabled={isLoading} className="flex-1">
              Test Sign Up
            </Button>
            <Button onClick={testSignIn} disabled={isLoading} className="flex-1">
              Test Sign In
            </Button>
          </div>

          {result && (
            <div className="mt-4 p-4 bg-muted rounded-md">
              <h3 className="font-medium mb-2">Result:</h3>
              <pre className="text-xs overflow-auto max-h-60">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
