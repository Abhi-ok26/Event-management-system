"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export default function SetupPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [results, setResults] = useState<Record<string, any>>({})
  const [error, setError] = useState<string | null>(null)

  async function runSetup() {
    setIsLoading(true)
    setError(null)
    setResults({})

    try {
      // Step 1: Set up database triggers
      const triggerResponse = await fetch("/api/auth/setup-triggers")
      const triggerResult = await triggerResponse.json()

      setResults((prev) => ({
        ...prev,
        triggers: {
          success: triggerResponse.ok,
          message: triggerResponse.ok ? "Database triggers set up successfully" : triggerResult.error,
        },
      }))

      if (!triggerResponse.ok) {
        setError("Failed to set up database triggers")
      }

      setIsLoading(false)
    } catch (err: any) {
      console.error("Setup error:", err)
      setError(err.message || "An unknown error occurred during setup")
      setIsLoading(false)
    }
  }

  useEffect(() => {
    runSetup()
  }, [])

  return (
    <div className="container flex min-h-screen w-full flex-col items-center justify-center py-10">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Authentication Setup</CardTitle>
          <CardDescription>Setting up your authentication system</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2">Setting up authentication...</span>
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              <Alert variant={results.triggers?.success ? "default" : "destructive"}>
                {results.triggers?.success ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4" />
                )}
                <AlertTitle>Database Triggers</AlertTitle>
                <AlertDescription>{results.triggers?.message}</AlertDescription>
              </Alert>

              <div className="rounded-md bg-muted p-4">
                <h3 className="font-medium mb-2">Setup Complete</h3>
                <p>Your authentication system is now set up. You can now:</p>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  <li>Register new users</li>
                  <li>Log in with email and password</li>
                  <li>Profiles will be automatically created for new users</li>
                </ul>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => (window.location.href = "/")}>
            Go to Home
          </Button>
          <Button onClick={runSetup} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Running...
              </>
            ) : (
              "Run Setup Again"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
