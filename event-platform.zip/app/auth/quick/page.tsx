import { QuickAuth } from "@/components/auth/quick-auth"
import { SocialLogin } from "@/components/auth/social-login"

export default function QuickAuthPage() {
  return (
    <div className="container py-10">
      <div className="mx-auto max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8">Quick Authentication</h1>

        <div className="space-y-8">
          <SocialLogin />
          <QuickAuth />
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          These methods provide immediate access to the platform.
        </p>
      </div>
    </div>
  )
}
