"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const verifySchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
})

const directLoginSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
})

type VerifyValues = z.infer<typeof verifySchema>
type DirectLoginValues = z.infer<typeof directLoginSchema>

export default function VerifyPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isDirectLoginLoading, setIsDirectLoginLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [emailSent, setEmailSent] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = getSupabaseBrowserClient()

  const verifyForm = useForm<VerifyValues>({
    resolver: zodResolver(verifySchema),
    defaultValues: {
      email: searchParams.get("email") || "",
    },
  })

  const directLoginForm = useForm<DirectLoginValues>({
    resolver: zodResolver(directLoginSchema),
    defaultValues: {
      email: searchParams.get("email") || "",
      password: "",
    },
  })

  async function onVerifySubmit(data: VerifyValues) {
    setIsLoading(true)
    setError(null)

    try {
      // Send a new confirmation email
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: data.email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error

      setEmailSent(true)
      toast({
        title: "Confirmation email sent",
        description: "Please check your inbox (and spam folder) for a new confirmation link.",
      })
    } catch (error: any) {
      setError(error.message || "Failed to send confirmation email")
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  async function onDirectLoginSubmit(data: DirectLoginValues) {
    setIsDirectLoginLoading(true)
    setError(null)

    try {
      // Try to sign in directly
      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      })

      if (error) throw error

      if (authData.session) {
        toast({
          title: "Login successful",
          description: "You have been logged in successfully.",
        })
        router.push("/")
        router.refresh()
      }
    } catch (error: any) {
      setError(error.message || "Failed to log in")
      toast({
        title: "Login failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDirectLoginLoading(false)
    }
  }

  return (
    <div className="container flex items-center justify-center min-h-[80vh] py-10">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Account Verification</CardTitle>
          <CardDescription>
            {emailSent
              ? "We've sent you a confirmation email. Please check your inbox."
              : "Verify your account or try alternative login methods"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Tabs defaultValue="email">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="email">Email Verification</TabsTrigger>
              <TabsTrigger value="direct">Direct Login</TabsTrigger>
            </TabsList>

            <TabsContent value="email">
              {emailSent ? (
                <div className="space-y-4">
                  <Alert className="bg-green-50 border-green-200">
                    <AlertDescription className="text-green-700">
                      A confirmation email has been sent. Please check your inbox and spam folder.
                    </AlertDescription>
                  </Alert>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      If you don't receive the email within a few minutes:
                    </p>
                    <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                      <li>Check your spam/junk folder</li>
                      <li>Verify that you entered the correct email address</li>
                      <li>Try the direct login option if you believe your account is already verified</li>
                    </ul>
                    <Button variant="outline" className="w-full mt-4" onClick={() => setEmailSent(false)}>
                      Try Again
                    </Button>
                  </div>
                </div>
              ) : (
                <Form {...verifyForm}>
                  <form onSubmit={verifyForm.handleSubmit(onVerifySubmit)} className="space-y-4">
                    <FormField
                      control={verifyForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? "Sending..." : "Send Confirmation Email"}
                    </Button>
                  </form>
                </Form>
              )}
            </TabsContent>

            <TabsContent value="direct">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  If you believe your account is already verified or you're having trouble with the email verification,
                  try logging in directly:
                </p>

                <Form {...directLoginForm}>
                  <form onSubmit={directLoginForm.handleSubmit(onDirectLoginSubmit)} className="space-y-4">
                    <FormField
                      control={directLoginForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={directLoginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="••••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" disabled={isDirectLoginLoading}>
                      {isDirectLoginLoading ? "Logging in..." : "Login"}
                    </Button>
                  </form>
                </Form>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="link" onClick={() => router.push("/auth/login")}>
            Return to Login
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
