import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const token = requestUrl.searchParams.get("token")
  const type = requestUrl.searchParams.get("type") || "signup"

  if (!token) {
    return NextResponse.redirect(new URL("/auth/error?error=missing_token", requestUrl.origin))
  }

  try {
    const supabase = getSupabaseServerClient()

    const { error } = await supabase.auth.verifyOtp({
      token_hash: token,
      type: type as any,
    })

    if (error) {
      return NextResponse.redirect(
        new URL(`/auth/error?error=${error.name}&error_description=${error.message}`, requestUrl.origin),
      )
    }

    // Redirect to success page
    return NextResponse.redirect(new URL("/auth/verification-success", requestUrl.origin))
  } catch (error: any) {
    console.error("Verification error:", error)
    return NextResponse.redirect(
      new URL(`/auth/error?error=verification_failed&error_description=${error.message}`, requestUrl.origin),
    )
  }
}
