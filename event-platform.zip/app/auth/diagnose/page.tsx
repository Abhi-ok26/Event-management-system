"use client"

import { useState, useEffect } from "react"
import { getSupabaseBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function DiagnosePage() {
  const [diagnostics, setDiagnostics] = useState<any>({})
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function runDiagnostics() {
      try {
        const supabase = getSupabaseBrowserClient()

        // Check if Supabase URL and anon key are defined
        const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
        const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

        const results: any = {
          environment: {
            supabaseUrl: supabaseUrl ? "Defined" : "Missing",
            supabaseAnonKey: supabaseAnonKey ? "Defined" : "Missing",
            nodeEnv: process.env.NODE_ENV,
          },
        }

        // Test connection
        try {
          const { data, error } = await supabase.from("profiles").select("count").limit(1)
          results.connection = {
            success: !error,
            error: error ? error.message : null,
            data,
          }
        } catch (e: any) {
          results.connection = {
            success: false,
            error: e.message,
          }
        }

        // Test auth system
        try {
          const { data, error } = await supabase.auth.getSession()
          results.auth = {
            success: !error,
            hasSession: !!data.session,
            error: error ? error.message : null,
          }
        } catch (e: any) {
          results.auth = {
            success: false,
            error: e.message,
          }
        }

        setDiagnostics(results)
      } catch (e: any) {
        setError(e.message || "An unknown error occurred during diagnostics")
      } finally {
        setIsLoading(false)
      }
    }

    runDiagnostics()
  }, [])

  return (
    <div className="container flex min-h-screen w-full flex-col items-center justify-center py-10">
      <Card className="w-full max-w-3xl">
        <CardHeader>
          <CardTitle>Supabase Diagnostics</CardTitle>
          <CardDescription>Checking your Supabase configuration and connection</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Running diagnostics...</div>
          ) : error ? (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">Environment Variables</h3>
                <div className="bg-muted p-4 rounded-md">
                  <pre className="text-xs">{JSON.stringify(diagnostics.environment, null, 2)}</pre>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Database Connection</h3>
                <Alert variant={diagnostics.connection?.success ? "default" : "destructive"}>
                  <AlertTitle>
                    {diagnostics.connection?.success ? "Connection Successful" : "Connection Failed"}
                  </AlertTitle>
                  <AlertDescription>
                    {diagnostics.connection?.error || "Successfully connected to Supabase database"}
                  </AlertDescription>
                </Alert>
                {diagnostics.connection?.data && (
                  <div className="mt-2 bg-muted p-4 rounded-md">
                    <pre className="text-xs">{JSON.stringify(diagnostics.connection.data, null, 2)}</pre>
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Authentication System</h3>
                <Alert variant={diagnostics.auth?.success ? "default" : "destructive"}>
                  <AlertTitle>{diagnostics.auth?.success ? "Auth System Working" : "Auth System Issue"}</AlertTitle>
                  <AlertDescription>
                    {diagnostics.auth?.error ||
                      (diagnostics.auth?.hasSession
                        ? "You are currently logged in"
                        : "You are not currently logged in")}
                  </AlertDescription>
                </Alert>
              </div>

              <div className="pt-4">
                <h3 className="text-lg font-medium mb-4">Troubleshooting Steps</h3>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Verify your Supabase project is active and properly configured</li>
                  <li>Check that your environment variables are correctly set</li>
                  <li>Ensure your Supabase project allows email/password authentication</li>
                  <li>Verify that Row Level Security (RLS) policies are properly configured</li>
                  <li>Check if email confirmations are required in your Supabase project</li>
                </ol>
              </div>

              <div className="flex justify-center pt-4">
                <Button onClick={() => window.location.reload()}>Run Diagnostics Again</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
